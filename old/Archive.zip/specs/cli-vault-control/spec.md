# cli-vault-control Specification

## Purpose
TBD - created by archiving change decouple-ui-from-graph-server. Update Purpose after archive.
## Requirements
### Requirement: CLI vault subcommands exist
The `voicetree-cli` binary (also exposed as `vt`) SHALL provide a `vault` subcommand group with the following operations: `add-read-path <path>`, `remove-read-path <path>`, `set-write-path <path>`, and `show`. Each SHALL invoke the corresponding `vt-graphd` HTTP endpoint.

#### Scenario: Add a read path from the CLI
- **WHEN** the user runs `vt vault add-read-path /Users/me/notes`
- **THEN** the CLI POSTs `{ "path": "/Users/me/notes" }` to the daemon's `/vault/read-paths` endpoint
- **AND** prints the updated list of read paths
- **AND** exits with code 0 on success

#### Scenario: Remove a read path
- **WHEN** the user runs `vt vault remove-read-path /Users/me/notes`
- **THEN** the CLI DELETEs the corresponding `/vault/read-paths/:encodedPath` endpoint
- **AND** prints the updated list of read paths

#### Scenario: Set the write path
- **WHEN** the user runs `vt vault set-write-path /Users/me/notes/inbox`
- **THEN** the CLI PUTs `{ "path": "..." }` to `/vault/write-path`
- **AND** prints the new write path

#### Scenario: Show vault state
- **WHEN** the user runs `vt vault show`
- **THEN** the CLI GETs `/vault` and prints `vaultPath`, `readPaths`, `writePath` in human-readable form

### Requirement: CLI view subcommands exist
The CLI SHALL provide a `view` subcommand group with: `collapse <folderId>`, `expand <folderId>`, `selection set <nodeIds...>`, `selection add <nodeIds...>`, `selection remove <nodeIds...>`, and `show`. Each SHALL invoke the corresponding session endpoint on the daemon.

#### Scenario: Collapse a folder via CLI
- **WHEN** the user runs `vt view collapse /Users/me/notes/projects/`
- **THEN** the CLI POSTs to `/sessions/:sessionId/collapse/<encoded folderId>`
- **AND** prints the updated session view summary

#### Scenario: Replace selection
- **WHEN** the user runs `vt view selection set /Users/me/notes/a.md /Users/me/notes/b.md`
- **THEN** the CLI POSTs `{ nodeIds: [...], mode: "replace" }` to `/sessions/:sessionId/selection`

### Requirement: CLI auto-launches the daemon when not running
If `vt-graphd` is not already running for the current vault, the CLI SHALL auto-launch it before issuing the request. The user SHALL NOT need to manually start the daemon.

#### Scenario: Cold start
- **GIVEN** the daemon is not running
- **WHEN** the user runs any `vt vault` or `vt view` subcommand
- **THEN** the CLI launches `vt-graphd --vault <detected-vault>` as a detached child process
- **AND** waits for the daemon's `/health` endpoint to respond with 200 (timeout: 5 seconds)
- **AND** then issues the original request

#### Scenario: Daemon already running
- **GIVEN** the daemon is already serving the current vault
- **WHEN** the user runs a CLI subcommand
- **THEN** the CLI reuses the running daemon (no new process spawned)

### Requirement: CLI vault auto-detection
The CLI SHALL auto-detect the target vault by walking up from the current working directory looking for a `.voicetree/` marker. The user SHALL be able to override with `--vault <path>`.

#### Scenario: cwd inside a vault
- **GIVEN** the cwd is `/Users/me/notes/projects` and `/Users/me/notes/.voicetree/` exists
- **WHEN** the user runs `vt vault show`
- **THEN** the CLI uses `/Users/me/notes` as the vault

#### Scenario: cwd outside any vault, no flag
- **WHEN** the user runs `vt vault show` from a directory not under any vault
- **THEN** the CLI exits with a non-zero code and prints a message instructing the user to pass `--vault <path>`

### Requirement: Session selection
The CLI SHALL accept `--session <sessionId>` to pin to an existing session. Without the flag, the CLI SHALL mint a fresh sessionId per invocation, OR reuse a session pinned via the `VT_SESSION` environment variable.

#### Scenario: Default fresh session
- **WHEN** the user runs `vt view show` with no `--session` flag and no `VT_SESSION` env
- **THEN** the CLI calls `POST /sessions` to mint a sessionId
- **AND** uses that sessionId for the request

#### Scenario: Pinned session via flag
- **WHEN** the user runs `vt --session abc view collapse <folderId>`
- **THEN** the CLI uses sessionId `abc` for the request
- **AND** does not mint a new session

### Requirement: Same backend function as the UI
For each operation that exists in both UI and CLI (read paths, write path, collapse, expand, selection, layout), the daemon SHALL invoke the same underlying function from `@vt/graph-model` or `@vt/graph-state`. There SHALL NOT be parallel implementations of the same operation.

#### Scenario: No drift between UI and CLI write-path semantics
- **WHEN** the UI sets the write path to `/foo` via IPC
- **AND** then the CLI sets it to `/bar` via HTTP
- **THEN** both invocations call `setWritePath()` from `@vt/graph-model/watch-folder-store`
- **AND** the resulting daemon state is identical to either call done twice in either order

#### Scenario: Lint enforces no direct imports outside daemon
- **WHEN** code outside `packages/graph-db-server/` imports a mutation function (e.g. `setWritePath`, `dispatchCollapse`) directly from `@vt/graph-model` or `@vt/graph-state`
- **THEN** the lint rule fails the build

### Requirement: CLI exit codes are meaningful
The CLI SHALL exit with code 0 on success, non-zero on failure. Failure modes SHALL include: daemon launch failure, network error reaching the daemon, daemon HTTP error response, validation error in arguments. Each SHALL print a distinct human-readable error message to stderr.

#### Scenario: Invalid path argument
- **WHEN** the user runs `vt vault add-read-path` with no path argument
- **THEN** the CLI exits with non-zero
- **AND** prints a usage message including the missing argument

#### Scenario: Daemon returns 4xx
- **WHEN** the daemon rejects the request (e.g. path does not exist)
- **THEN** the CLI exits with non-zero
- **AND** prints the daemon's error message

