## 1. Phase B1 — Graph-model: kind discriminator + folder-note resolver

- [x] 1.1 Add required `kind: 'leaf' | 'folder'` field to `GraphNode` interface in `packages/graph-model/src/pure/graph/index.ts`.
- [x] 1.2 Update every `GraphNode` constructor — `parseMarkdownToGraphNode`, `addNodeToGraphWithEdgeHealingFromFSEvent`, `buildGraphFromFiles`, fixtures, test helpers — to set `kind: 'leaf'`. — `271bb62e`
- [x] 1.3 Create `packages/graph-model/src/pure/graph/folder-note/getFolderNotePath.ts` exporting `getFolderNotePath(graph: Graph, folderId: FolderId): NodeIdAndFilePath | undefined` per design rules (`<folder>/index.md` first; `<folder>/<basename>.md` fallback; else `undefined`).
- [x] 1.4 Re-export `getFolderNotePath` from `packages/graph-model/src/pure/graph/index.ts` so consumers import via `@vt/graph-model`.
- [x] 1.5 Unit tests for `getFolderNotePath` covering: index.md preferred, basename fallback, undefined when neither, behavior when folderId missing trailing slash (lock chosen behavior in test).
- [x] 1.6 Run `cd packages/graph-model && npm test`; commit `feat(graph-model): GraphNode.kind + getFolderNotePath resolver (Jay/B1)`. — `271bb62e`

## 2. Phase B2 — Graph-state: project.ts emits folder content

- [x] 2.1 Import `getFolderNotePath` into `packages/graph-state/src/project.ts`. — `08eb2550`
- [x] 2.2 In `dataForFolder` (or a new helper), when emitting a folder NodeElement, resolve its folder-note via `getFolderNotePath(state.graph, info.id)` and set `data.content` to that node's `contentWithoutYamlOrLinks` (empty string if none). — `08eb2550`
- [x] 2.3 Apply uniformly to expanded (`'folder'`) and collapsed (`'folder-collapsed'`) NodeElements. — `08eb2550`
- [x] 2.4 Add tests in the existing graph-state projection test file (find current location with `rg "describe.*project" packages/graph-state/`) for: folder with index.md, folder with basename.md fallback, folder with neither (empty string), collapsed folder still carries content. — `08eb2550`
- [x] 2.5 Run `cd packages/graph-state && npm test`; commit `feat(graph-state): project emits folder-note content on folder NodeElements (Jay/B2)`. — `08eb2550`

## 3. Phase B3 — Webapp reconciler: folder cy nodes get content

- [x] 3.1 In `webapp/src/shell/edge/UI-edge/graph/applyGraphDeltaToUI.ts`, in the folder insert path (~line 209), add `content: asString(specNode.data['content']) ?? ''` to the cy data. — `9dd8746d`
- [x] 3.2 In the folder update path (~line 258), set `existing.data('content', asString(specNode.data['content']) ?? '')`. — `9dd8746d`
- [x] 3.3 Add tests in `webapp/src/shell/edge/UI-edge/graph/integration-tests/applyGraphDeltaToUI.test.ts`: insert folder spec with content → cy gets content; update folder spec with new content → cy reflects update. — `9dd8746d`
- [x] 3.4 Run `cd webapp && npx vitest run src/shell/edge/UI-edge/graph/integration-tests/applyGraphDeltaToUI.test.ts`; commit `feat(reconciler): folder cy nodes carry data.content (Jay/B3)`. — `9dd8746d`

## 4. Phase B4 — Webapp editor: uniform folder open + first-save creates index.md

- [x] 4.1 In `createAnchoredFloatingEditor` (`webapp/src/shell/edge/UI-edge/floating-windows/editors/AnchoredEditor.ts`), detect folder ids (`nodeId.endsWith('/')`); resolve folder-note via a renderer-side accessor (likely `window.electronAPI.main.getGraph()` then `getFolderNotePath`); pass the resolved leaf id into `createFloatingEditor` if found; otherwise pass the folder id and use empty initial content. — `83f707f6`
- [x] 4.2 In `modifyNodeContentFromUI` (`webapp/src/shell/edge/UI-edge/floating-windows/editors/modifyNodeContentFromFloatingEditor.ts`), if the incoming `nodeId` ends with `/`, redirect the save to `<nodeId>index.md` and construct the file-create graph delta via `addNodeToGraphWithEdgeHealingFromFSEvent` (or equivalent); subsequent saves go to the now-real `index.md`. — `83f707f6`
- [x] 4.3 Anchor cleanup: `anchorEditorToRealNode` already uses `cy.getElementById(nodeId)` — ensure folder cy nodes (compound parents) anchor cleanly. The compound-parent cy node has dimensions derived from children; the editor mounts on the folder's bounding box. If overlay placement requires a non-compound anchor, fall back to the folder-note's leaf cy node when present. — `83f707f6`
- [x] 4.4 Add a focused integration test in `webapp/src/shell/edge/UI-edge/graph/integration-tests/applyLiveCommandToRenderer.editor-mount.test.ts` (or a new sibling): tap folder with index.md → editor opens with folder-note content; tap folder without index.md → editor opens empty; type → autosave → assert FS write to `<folder>/index.md` (mock as needed). — `83f707f6`
- [x] 4.5 Run `cd webapp && npm test`; commit `feat(editor): uniform folder/file editor open + first-save index.md (Jay/B4)`. — `83f707f6`

## 5. Phase B5 — Webapp layout: folders participate in Cola

- [x] 5.1 In `webapp/src/shell/UI/cytoscape-graph-ui/layoutParticipation.ts`, change `isLayoutParticipantNode` to return `true` for `isFolderNode` regardless of `collapsed`. Keep `isContextNode` exclusion. — `3b645780`
- [x] 5.2 Update `webapp/src/shell/UI/cytoscape-graph-ui/layoutParticipation.test.ts` cases: expanded folder participates, collapsed folder participates, context node still excluded. — `3b645780`
- [x] 5.3 Audit `webapp/src/shell/UI/cytoscape-graph-ui/graphviz/layout/autoLayoutLocalCola.ts` — confirm all three call sites of `isLayoutParticipantNode` already gate folder filtering. If they do, no further change needed. — `3b645780`
- [x] 5.4 Audit other call sites of `isFolderNode` outside `layoutParticipation.ts` (search `rg "isFolderNode" webapp/src`) and decide whether each one is still load-bearing or should route through the participation gate. Document any deferrals as follow-ups, do NOT mass-refactor. — `3b645780`
- [x] 5.5 Run `cd webapp && npx vitest run src/shell/UI/cytoscape-graph-ui/layoutParticipation.test.ts`; commit `feat(layout): folders participate in Cola layout (Jay/B5)`. — `3b645780`

## 6. Synthesis

- [x] 6.1 After B5 lands, write progress node `B1 orchestrator complete — unified-folder-file-nodes shipped` listing all five commit SHAs, any deferrals, and live-verify status (expected: blocked on user re-opening vault to exercise folder editor). — evidence: `B1 orchestrator complete — unified-folder-file-nodes shipped`
