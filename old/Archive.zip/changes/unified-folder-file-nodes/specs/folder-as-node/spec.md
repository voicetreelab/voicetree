## ADDED Requirements

### Requirement: GraphNode SHALL carry a kind discriminator

The `GraphNode` interface SHALL declare a required `kind` field with values `'leaf' | 'folder'`. Every constructor of `GraphNode` (file parsing, FS-event mapping, fixtures, test helpers) SHALL set `kind = 'leaf'` for nodes derived from markdown files.

#### Scenario: Existing file-derived GraphNodes are leaves
- **GIVEN** a markdown file is read from disk via `buildGraphFromFiles`
- **WHEN** the resulting `GraphNode` is inspected
- **THEN** `node.kind === 'leaf'`

#### Scenario: TypeScript enforces kind at construction
- **GIVEN** a code path that constructs a `GraphNode` literal without a `kind` field
- **WHEN** the project compiles
- **THEN** TypeScript reports a missing-property error

### Requirement: getFolderNotePath SHALL resolve a folder's folder-note id

The system SHALL expose `getFolderNotePath(graph: Graph, folderId: FolderId): NodeIdAndFilePath | undefined` from `@vt/graph-model`. Resolution SHALL try `<folder>/index.md` first; if absent from the graph, SHALL try `<folder>/<basename>.md` where `basename` is the final non-empty path segment of `folderId`. If neither file is in the graph, SHALL return `undefined`.

#### Scenario: index.md preferred when present
- **GIVEN** a graph containing `/vault/topic/index.md` and `/vault/topic/topic.md`
- **WHEN** `getFolderNotePath(graph, '/vault/topic/')` is called
- **THEN** the result equals `'/vault/topic/index.md'`

#### Scenario: basename fallback when index.md missing
- **GIVEN** a graph containing `/vault/topic/topic.md` but NO `/vault/topic/index.md`
- **WHEN** `getFolderNotePath(graph, '/vault/topic/')` is called
- **THEN** the result equals `'/vault/topic/topic.md'`

#### Scenario: undefined when no folder-note present
- **GIVEN** a graph containing `/vault/topic/childA.md` and `/vault/topic/childB.md` only
- **WHEN** `getFolderNotePath(graph, '/vault/topic/')` is called
- **THEN** the result is `undefined`

#### Scenario: trailing slash required on folderId
- **GIVEN** any graph
- **WHEN** `getFolderNotePath(graph, '/vault/topic')` is called (no trailing slash)
- **THEN** the function still resolves correctly OR throws — pick one and document; tests SHALL lock the chosen behavior

### Requirement: project() SHALL emit folder-note content on folder NodeElements

`project(state)` SHALL populate `data.content` on every emitted folder NodeElement (kind `'folder'` and `'folder-collapsed'`) with the `contentWithoutYamlOrLinks` of the folder-note resolved by `getFolderNotePath`. If no folder-note exists, `data.content` SHALL be the empty string.

#### Scenario: Folder NodeElement carries folder-note content
- **GIVEN** a `State` whose graph contains `/vault/topic/index.md` with content `# Topic\n\nbody`
- **WHEN** `project(state)` is called
- **THEN** the emitted NodeElement for folder id `/vault/topic/` has `data.content === '# Topic\n\nbody'`

#### Scenario: Folder without folder-note has empty content
- **GIVEN** a `State` whose graph contains `/vault/topic/childA.md` only
- **WHEN** `project(state)` is called
- **THEN** the emitted NodeElement for folder id `/vault/topic/` has `data.content === ''`

#### Scenario: Collapsed folders also carry content
- **GIVEN** a folder is in `state.collapseSet`
- **WHEN** `project(state)` is called
- **THEN** the emitted NodeElement (kind `'folder-collapsed'`) has `data.content` populated identically to the expanded case

### Requirement: applyGraphDeltaToUI SHALL copy folder content into cy

The renderer reconciler SHALL set `content` on cy folder nodes from `NodeElement.data.content` on both insert and update paths. Existing folder data fields (`isFolderNode`, `folderLabel`, `collapsed`, `childCount`) SHALL be preserved.

#### Scenario: New folder cy node receives content
- **GIVEN** the reconciler runs against an empty cy with a spec containing a folder NodeElement with `data.content === '# Topic'`
- **WHEN** `applyGraphDeltaToUI(cy, spec)` returns
- **THEN** `cy.getElementById(folderId).data('content') === '# Topic'`
- **AND** `cy.getElementById(folderId).data('isFolderNode') === true`

#### Scenario: Existing folder cy node updates content
- **GIVEN** the reconciler runs twice with different `data.content` for the same folder
- **WHEN** the second call completes
- **THEN** the cy node's `data('content')` reflects the second spec's value

### Requirement: createAnchoredFloatingEditor SHALL open folder-notes uniformly

When called with a folder id (a string ending in `/`), `createAnchoredFloatingEditor` SHALL resolve the folder-note via `getFolderNotePath`, mount the editor on the resolved file id (or on the folder id itself if no folder-note exists yet), and on first save SHALL create `<folder>/index.md` with the editor's content.

#### Scenario: Folder click opens folder-note when present
- **GIVEN** a graph containing `/vault/topic/index.md`
- **WHEN** `createAnchoredFloatingEditor(cy, '/vault/topic/')` is called
- **THEN** the editor's `contentLinkedToNodeId === '/vault/topic/index.md'`
- **AND** the initial editor content equals the markdown of `/vault/topic/index.md`

#### Scenario: Folder click on folder without folder-note opens empty editor
- **GIVEN** a graph containing `/vault/topic/childA.md` only
- **WHEN** `createAnchoredFloatingEditor(cy, '/vault/topic/')` is called
- **THEN** an editor mounts anchored to the folder cy node
- **AND** the initial editor content is the empty string

#### Scenario: First save of empty folder editor creates index.md
- **GIVEN** an editor opened on a folder without a folder-note
- **WHEN** the user types content and the autosave dispatches
- **THEN** `<folder>/index.md` is created on disk with that content
- **AND** subsequent FS deltas see it as a regular leaf GraphNode

### Requirement: Folder cy nodes SHALL participate in layout

`layoutParticipation.isLayoutParticipantNode(node)` SHALL return `true` for folder cy nodes (both compound parents whose children are visible AND collapsed atoms). Auto-layout (`autoLayoutLocalCola`) SHALL include folders in its run set, pin set, and obstacle calculations.

#### Scenario: Expanded folder is a layout participant
- **GIVEN** a cy folder node with `isFolderNode: true` and no `collapsed` flag
- **WHEN** `isLayoutParticipantNode(node)` is called
- **THEN** the result is `true`

#### Scenario: Collapsed folder is a layout participant
- **GIVEN** a cy folder node with `isFolderNode: true` and `collapsed: true`
- **WHEN** `isLayoutParticipantNode(node)` is called
- **THEN** the result is `true`

#### Scenario: Cola layout positions folders alongside leaves
- **GIVEN** a graph with two leaf nodes and one folder node containing one of them
- **WHEN** `runLocalCola` is invoked on the new leaf
- **THEN** the folder node appears in the run set or pin set (not silently filtered)
- **AND** layout completes without throwing
