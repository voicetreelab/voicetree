## Why

Today files and folders are modeled as different things end-to-end:

- `GraphNode` only ever represents a file. Folders never carry content, edges, or selection at the model layer.
- The renderer derives folder compound nodes from `state.roots.folderTree` at projection time and treats them as visual scaffolding (compound parents only — no text, no editor, no layout participation).
- Click-to-edit, layout, and most graph tooling all branch on `data('isFolderNode')` to short-circuit folder nodes out of every interaction.

Wave A reproductions (see `dae-folder-node-regression-repro.md`) confirmed how brittle this dual-model is — the renderer state mirror could ship empty `roots.folderTree` and folders silently disappeared without any model-level invariant detecting it. Folders feel like second-class citizens to the user too: they cannot be opened, edited, or laid out.

We want folders and files to be the same kind of thing in the graph (`kind: 'leaf' | 'folder'`), each carrying content (a folder's content is its folder-note), each editable, each laid out. The only legitimate divergence is at the rendering boundary, where a folder may render as a compound (expanded) or a single node with a count badge (collapsed). That divergence stays on `NodeElement.kind` (the projection contract), not on `GraphNode.kind`.

## What Changes

- **`GraphNode.kind` field** added with values `'leaf' | 'folder'`. Existing file-derived GraphNodes are `'leaf'`. Folders that contain projectable descendants become `'folder'` GraphNodes with `absoluteFilePathIsID = <folder>/` (trailing slash, matching `FolderId`).
- **`getFolderNotePath(graph, folderId)` resolver** in `@vt/graph-model`. Returns the absolute id of the folder-note for a folder: prefers `<folder>/index.md`, falls back to `<folder>/<basename>.md`, else `undefined`.
- **`project(state)` populates `data.content` on folder NodeElements** by reading the folder-note's `contentWithoutYamlOrLinks` via `getFolderNotePath`. NodeElement.kind is unchanged (`'folder' | 'folder-collapsed'` for folders).
- **`applyGraphDeltaToUI` propagates `data.content` to cy** for folder cy nodes (in addition to the existing `isFolderNode`, `folderLabel`, `collapsed`, `childCount`).
- **`createAnchoredFloatingEditor` works uniformly for folder ids**. Opening a folder mounts the editor on the folder-note. If the folder has no folder-note yet, the first save creates `<folder>/index.md`.
- **Layout participation includes folders**. `layoutParticipation.ts` is the gate — folders (collapsed AND expanded compound parents) participate in Cola layout symmetrically with leaves. Existing call sites stop short-circuiting on `data('isFolderNode')` and route through the gate.

### Capabilities

#### New Capabilities
- `folder-as-node`: a folder is a first-class graph node — addressable, editable, laid out, and projected with `data.content` from its folder-note.

### Modified Capabilities
- `folder-collapse` (existing) — unchanged behavior; still derives `'folder' | 'folder-collapsed'` on `NodeElement.kind` from `state.collapseSet`. Now operates on folders that ALSO carry content.

## Impact

- `packages/graph-model/src/pure/graph/index.ts` — extend `GraphNode` interface with `kind`.
- `packages/graph-model/src/pure/graph/folder-note/getFolderNotePath.ts` (new) — resolver.
- `packages/graph-state/src/project.ts` — populate `data.content` on folder NodeElements; thread `getFolderNotePath` through `dataForFolder`.
- `webapp/src/shell/edge/UI-edge/graph/applyGraphDeltaToUI.ts` — copy `content` data into folder cy nodes (insert + update paths).
- `webapp/src/shell/edge/UI-edge/floating-windows/editors/AnchoredEditor.ts` + `FloatingEditorCRUD.ts` — folder-id branch that resolves to folder-note, with first-save creates-`index.md` semantics.
- `webapp/src/shell/edge/UI-edge/floating-windows/editors/modifyNodeContentFromFloatingEditor.ts` — handle save when target nodeId is a folder id (write to folder-note path; create file on first save).
- `webapp/src/shell/UI/cytoscape-graph-ui/layoutParticipation.ts` — relax `isLayoutParticipantNode` so folders participate (both collapsed and expanded). Existing call sites in `autoLayoutLocalCola.ts`, `cola.test.ts`, `applyPendingPan.ts`, `extractObstaclesFromCytoscape.ts`, `viewportVisibility.ts`, `SearchService.ts`, `defaultNodeStyles.ts`, `updateNodeSizes.ts`, `spatialIndexSync.test.ts` stay as-is and inherit the relaxed semantics.

Wave A (already landed) — empty-folder prune, extract-into-folder auto-collapse, sidebar populate from main snapshot, renderer mirror dual-source folderTree — is preserved and re-verified by this change's tests.

Wave C (deferred) — `.vt-session/collapse.json` shared-collapse state — is mentioned in design.md but NOT implemented here.
