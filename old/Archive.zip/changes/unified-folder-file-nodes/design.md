## Context

Wave A landed four bug fixes that left the renderer materializing folder NodeElements again (commits `eded32eb`, `edf1fb31`, `cb0ade3c`, `299f4342`). With folders visible, the next problem surfaces: folders are visible but inert. They have no content, no editor, no role in layout. This change unifies the type system and behavior so folders are editable, laid-out graph members.

Relevant constraints:
- `GraphNode.absoluteFilePathIsID` already typed as `FilePath` (string). A trailing-slash folder path is a valid string id.
- `FolderId` from `@vt/graph-state/contract` is `<absolutePath>/` — same shape we'd use for a folder GraphNode id.
- `NodeElement.kind` is `'node' | 'folder' | 'folder-collapsed'` today (renderer-facing). The renderer needs all three because compound vs simple shape differs.
- The renderer's `applyGraphDeltaToUI` is now a pure projection-reconciler (BF-L5-202b) — it derives cy state from the spec; we add the content field rather than threading new IPC.
- Wave A's `project.ts` empty-folder prune already guarantees folder NodeElements only appear when there are projectable file descendants, so a folder is always semantically meaningful at the moment we project it.

## Goals / Non-Goals

**Goals**:
- Folders carry content (their folder-note's content) at the model and projection layers.
- One uniform editor open path for files and folders.
- Folders participate in layout symmetrically with leaves.
- The renderer keeps its three NodeElement kinds — derivation only, no behavior bifurcation in callers.

**Non-Goals**:
- Persisting collapse state across sessions (`.vt-session/collapse.json`) — Wave C.
- Folder rename / move semantics — out of scope; rename pipeline is unaffected (folder-note rename uses existing rename pipeline once the editor saves it).
- Backwards-migrating existing vaults to add `index.md` files — files are created lazily on first save.
- Synthetic edges to/from folder GraphNodes — folder-collapse synthetic edges remain unchanged; we don't add new edge semantics.

## Decisions

1. **`NodeElement.kind` retains all three variants** (`'node' | 'folder' | 'folder-collapsed'`).
   Rationale: The renderer needs to know whether to render a compound parent (expanded folder) vs a simple node (file or collapsed folder). That distinction is geometric, not ontological — keep it on the projection contract, not the model.
   Alternatives considered: collapse to `'leaf' | 'folder'` and let renderer decide → loses information that the projection already computed (visible-collapsed-folder set).

2. **Folder-note resolution: prefer `<folder>/index.md`, fallback to `<folder>/<basename>.md`.**
   Rationale: `index.md` is conventional and unambiguous. The basename fallback supports vaults where the convention is `mytopic/mytopic.md`.
   Alternatives considered:
   - First markdown in folder (rejected): unstable across reorderings; surprising to user.
   - Required `index.md` only (rejected): breaks existing vaults using basename convention; folder-tools/hygiene already handles both via `folderIndexMap`.

3. **Folder GraphNodes are synthesized at graph-build time, not stored on disk.**
   Rationale: Folders aren't files; they have no on-disk representation as nodes. The folder GraphNode is a derived view: id = `<folder>/`, content = `getFolderNotePath` resolution, edges = (none for now). When a folder has zero projectable file descendants we omit it (matches Wave A prune).
   Alternatives considered:
   - Store folder placeholder files (rejected): pollutes filesystem, forces vault migration.
   - Materialize folder GraphNodes only on `project()` (rejected for B1, accepted at projection layer in B2): scope creeps into model layer; B1 lays the type-system foundation, B2 wires the data.

4. **First save of a folder editor creates `<folder>/index.md`.**
   Rationale: Lazy creation — the folder GraphNode shows empty content until the user actually writes; once they do, we materialize the file via the existing FS write pipeline. No upfront migration.
   Alternatives considered:
   - Pre-create on folder open (rejected): noisy filesystem churn for folders the user merely browses.
   - Save to in-memory only (rejected): violates the markdown-is-source-of-truth invariant.

5. **Layout participation gate moves entirely to `layoutParticipation.ts`.**
   Rationale: Single point of truth for "should this element participate in Cola." Today it excludes folders unconditionally except when collapsed. We relax it: folders participate as compound parents (their bounding box is derived from children, so Cola handles them naturally) and as collapsed atoms.
   Alternatives considered:
   - Per-call-site relaxation (rejected): we already centralized this in the layoutParticipation file; keep the seam.

6. **`GraphNode.kind` is required (not optional).**
   Rationale: A required discriminator is safer in TypeScript — every constructor must declare it, preventing the silent-undefined drift that has bitten us before.
   Migration: every `GraphNode` constructor (`buildGraphFromFiles`, `parseMarkdownToGraphNode`, FS event handlers, test fixtures) gets `kind: 'leaf'`.

## Risks / Trade-offs

- **Folder GraphNodes break callers that assume `state.graph.nodes[id]` keys are file paths.** → Mitigation: B1 only adds the field; B2 emits content from the folder-note file (a real leaf node) — folder GraphNodes are synthesized at projection time, not added to `state.graph.nodes`. The `kind` field on stored GraphNodes remains `'leaf'` for everyone existing.
- **Folder editor save races with FS watcher add-event.** → Accept; the existing edit pipeline already handles file-create through the same `applyGraphDeltaToDBThroughMemAndUIExposed` path.
- **Cola may behave oddly with compound parents that have non-zero content (text inside the box).** → Compound parent dimensions are computed from children today; folder-note content is rendered inside the editor overlay, not as cy node text — the cy node continues to be a label-only compound. Editing happens through the existing floating-editor anchor mechanism.
- **Folder-id collision with file path that happens to end in `/`.** → File paths cannot end in `/` (filesystem invariant). No collision possible.
- **First-save create-`index.md` may surprise users who expected the folder to remain empty.** → Acceptable; the editor is opened on explicit click — implicit consent.

## Migration Plan

1. **B0 — openspec change**: this document. No code change.
2. **B1 — graph-model**: add `kind` field; add resolver; update fixtures + tests; commit.
3. **B2 — graph-state**: project.ts threads `getFolderNotePath` to populate `data.content` on folder NodeElements; update projection tests; commit.
4. **B3 — webapp reconciler**: applyGraphDeltaToUI copies `content` to folder cy nodes (insert + update); test in `applyGraphDeltaToUI.test.ts`; commit.
5. **B4 — webapp editor**: createAnchoredFloatingEditor handles folder ids → resolves folder-note → mounts editor → first-save creates the file; test in `applyLiveCommandToRenderer.editor-mount.test.ts` or new sibling; commit.
6. **B5 — webapp layout**: relax `layoutParticipation.ts` to include folders; update `layoutParticipation.test.ts`; commit.
7. **Wave C (deferred)**: persist collapse state to `.vt-session/collapse.json`.

Rollback: each phase is a separate commit. To roll back a phase, revert its commit. The phases are layered (B2 depends on B1, B3 depends on B2, etc.), so rollback proceeds in reverse order. No feature flag — the change is internal plumbing with user-visible benefit only after B4 lands.

## Open Questions

- Should folder GraphNodes appear in `state.graph.nodes` (storage layer), or only in the projection? **Locked**: storage stays files-only; folder representation is projection-only via `getFolderNotePath`.
- Should the folder editor handle non-`.md` folder-notes (e.g., `index.markdown`)? **Deferred**: out of scope; resolver tries `index.md` and `<basename>.md` only.
- How do agent-driven edits (MCP) on a folder propagate? **Out of scope**: agents continue to edit files; if they target a folder id, the same B4 first-save semantics apply.
