## ADDED Requirements

### Requirement: Multi-selection SHALL support grouping into a filesystem folder
The system SHALL provide a `Group into folder` action for multi-selected file nodes and execute grouping as real filesystem operations.

#### Scenario: Group action appears for valid selection
- **WHEN** a user selects two or more markdown file nodes
- **THEN** the node context menu includes `Group into folder`

#### Scenario: Grouping creates destination and moves files
- **WHEN** a user confirms `Group into folder` with a folder name
- **THEN** the system creates a new directory under the nearest common ancestor directory of the selected files
- **THEN** the system moves each selected markdown file into the created directory
- **THEN** grouping is persisted on disk rather than only in UI state

### Requirement: Grouping SHALL reconcile through existing filesystem watcher flow
The system SHALL rely on filesystem watcher delete/add events and graph deltas to reflect grouped node paths in the graph model and UI.

#### Scenario: Moved files are rehydrated as new node IDs
- **WHEN** grouping emits filesystem delete and add events for moved files
- **THEN** old path node IDs are removed from the graph model
- **THEN** new path node IDs are added to the graph model
- **THEN** the UI renders files under their new folder parent relationships

### Requirement: Grouping SHALL preserve wikilink edge semantics
The system SHALL preserve basename-resolved wikilink behavior after folder moves.

#### Scenario: Basename wikilinks continue to resolve
- **WHEN** files are moved into a grouping folder without introducing basename collisions
- **THEN** existing `[[basename]]` references continue resolving to those moved files
- **THEN** corresponding graph edges are restored after delta reprocessing without manual link edits

### Requirement: Grouping SHALL fail safely on filesystem errors
The system SHALL report grouping failures and prevent silent data loss.

#### Scenario: Filesystem operation failure
- **WHEN** destination directory creation or any move operation fails
- **THEN** the system reports an actionable error to the user
- **THEN** the system performs best-effort rollback for any already moved files in the same operation
- **THEN** the final reported state identifies unresolved partial moves, if any, for manual recovery
