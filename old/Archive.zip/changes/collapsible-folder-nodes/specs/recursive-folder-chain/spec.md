## ADDED Requirements

### Requirement: The graph SHALL create recursive folder compounds within loaded roots
The system SHALL create nested folder compound nodes for each directory segment between a loaded top-level folder and a file's immediate parent directory.

#### Scenario: Intermediate folder chain is materialized
- **WHEN** a file path under a loaded root contains nested directories
- **THEN** each intermediate directory is represented as a folder compound node
- **THEN** each intermediate folder node has a Cytoscape parent equal to its immediate ancestor folder
- **THEN** the file node parent equals its immediate containing folder node

### Requirement: Ancestor chains above loaded roots SHALL NOT auto-render
The system MUST NOT create folder compound nodes for directories above folders explicitly loaded into the graph workspace.

#### Scenario: Sidebar-loaded root limits chain creation
- **WHEN** a folder is loaded from the sidebar as a top-level graph folder
- **THEN** directories above that loaded root are not materialized in the graph
- **THEN** those ancestors appear only if explicitly loaded from the sidebar

### Requirement: Newly introduced subfolders SHALL default to collapsed
The system SHALL add visible subfolder nodes in collapsed state by default.

#### Scenario: Parent expansion introduces subfolder children
- **WHEN** an expanded folder reveals subfolder children
- **THEN** each revealed subfolder is rendered collapsed
- **THEN** descendants of those subfolders remain hidden until explicit expansion

### Requirement: Empty folder compounds SHALL be cleaned up recursively
The system SHALL remove folder compound nodes that no longer contain modeled descendants inside a loaded subtree.

#### Scenario: Last descendant removal prunes folders
- **WHEN** graph delta processing removes the final descendant of a folder
- **THEN** that folder node is removed from Cytoscape
- **THEN** ancestor folder nodes are removed only if they also become empty and are not loaded roots
