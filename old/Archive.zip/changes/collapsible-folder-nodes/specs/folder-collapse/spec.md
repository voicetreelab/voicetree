## ADDED Requirements

### Requirement: Folder nodes SHALL support collapse and expand in the graph
The system SHALL allow users to toggle folder compound nodes between expanded and collapsed states in the Cytoscape workspace.

#### Scenario: Collapsing a folder hides descendants
- **WHEN** a user collapses an expanded folder node
- **THEN** all descendant child nodes are removed from Cytoscape
- **THEN** all edges whose source or target is a removed descendant are removed from Cytoscape
- **THEN** the folder node remains visible in a collapsed visual state with a descendant count

#### Scenario: Expanding a folder restores direct children
- **WHEN** a user expands a collapsed folder node
- **THEN** the system re-adds the folder's direct children from the graph model into Cytoscape
- **THEN** file children become visible
- **THEN** folder children are inserted in collapsed state by default

### Requirement: Collapse SHALL NOT create synthetic summary edges
The system MUST NOT synthesize summary edges for hidden descendants when a folder is collapsed.

#### Scenario: External descendant edges are not projected
- **WHEN** a collapsed folder contains hidden descendants with external graph connections
- **THEN** those descendant edges are absent from Cytoscape while the folder remains collapsed
- **THEN** only edges attached to currently rendered nodes remain visible

### Requirement: Collapse state SHALL survive graph delta updates
The system SHALL preserve folder collapse state while processing add/change/delete graph deltas.

#### Scenario: Delta update under collapsed folder
- **WHEN** filesystem or graph delta updates affect files beneath a collapsed folder
- **THEN** the folder remains collapsed after update application
- **THEN** descendants remain hidden until explicit expansion
- **THEN** the displayed descendant count reflects the updated modeled descendants
