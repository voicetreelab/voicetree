## Why

After ~1 hour of usage, the Cytoscape graph becomes unusable due to accumulated node count. Users manually manage folders and create new voicetrees as a workaround. Folder compound nodes exist but don't collapse — all children are still rendered, giving visual grouping but zero performance benefit.

Collapsible folder nodes solve this by bounding visible nodes to what the user has explicitly expanded. Folders become the universal unit of organization — vaults, agent work clusters, and manual groupings all collapse the same way.

## What Changes

- **Recursive folder compound chain**: Replace single-level `getFolderParent()` in `applyGraphDeltaToUI.ts` with `ensureFolderChain()` that creates nested compound nodes for each directory level, with correct Cytoscape `parent` relationships between them.
- **Collapse/expand toggle on folder nodes**: Collapsing a folder removes its children (and their edges) from Cytoscape, leaving a single folder node with a child count badge. Expanding re-adds children from the graph model. All subfolders collapsed by default.
- **"Group into folder" via filesystem move**: Multi-select nodes, right-click, group into a named folder. This physically moves files into a new subdirectory on disk. The FS watcher fires delete+add events, wikilink basename resolution preserves edge integrity automatically.
- **Filetree sidebar as navigation, graph as workspace**: The sidebar handles filesystem browsing. Clicking a folder in the sidebar loads it into the graph. The graph only shows loaded/expanded content — no ancestor chain explosion.
- **Agent API for folder grouping**: Agents can create folders and move nodes into them, enabling automatic clustering of related work.

## Capabilities

### New Capabilities
- `folder-collapse`: Toggle collapse/expand on folder compound nodes in the Cytoscape graph. Collapsed folders hide children and their edges, showing only a single node with count. Expanded folders show children and nested collapsed subfolders.
- `group-into-folder`: Multi-select nodes and group them into a new filesystem subdirectory via right-click menu. Files are physically moved; edges survive via wikilink basename resolution.
- `recursive-folder-chain`: Nested compound node creation so subfolders render inside their parent folders in the graph, enabling recursive collapse.

### Modified Capabilities

## Impact

- `webapp/src/shell/edge/UI-edge/graph/applyGraphDeltaToUI.ts` — replace `getFolderParent` + lazy single-folder creation with recursive `ensureFolderChain()`
- `webapp/src/shell/UI/cytoscape-graph-ui/services/defaultNodeStyles.ts` — collapsed folder node styling (count badge, distinct visual state)
- `webapp/src/shell/UI/cytoscape-graph-ui/services/getNodeMenuItems.ts` — add "Group into folder" to multi-select context menu
- `webapp/src/shell/UI/cytoscape-graph-ui/graphviz/layout/autoLayoutLocalCola.ts` — ensure collapsed folders participate in layout as normal nodes
- Cola layout, edge sync, and node size calculations already filter `isFolderNode` — collapse toggle must integrate with these
- MCP server tools (spawn_agent, create_graph) — expose folder grouping for agent use
- Addresses BF-036 (backlog, priority 2, complexity 8)
