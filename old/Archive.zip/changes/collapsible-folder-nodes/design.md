## Context

The current graph UI creates folder compound nodes from file paths, but only at a single level and without true collapse semantics. As node count grows during long sessions, Cytoscape performance degrades because all children remain rendered even when visually grouped. The existing filetree sidebar already handles filesystem navigation well, so the graph should behave as a focused workspace rather than a full filesystem browser.

Relevant constraints:
- Node IDs are absolute markdown file paths.
- Folder membership is derived from filesystem directories.
- Cytoscape `parent` is immutable after node creation.
- File moves are already represented by the watcher pipeline as delete + add graph deltas.

## Goals / Non-Goals

**Goals:**
- Bound rendered graph size by explicit expansion state.
- Make folders the universal grouping primitive (vaults, agent clusters, manual groups).
- Use real filesystem operations as the source of truth for grouping.
- Support nested subfolders via recursive compound chain creation.
- Keep sidebar-driven navigation and graph workspace behavior aligned.

**Non-Goals:**
- Synthetic summary edges for collapsed folders in v1.
- Virtual grouping metadata that diverges from filesystem structure.
- Automatic rendering of full ancestor chains above user-loaded roots.
- Solving basename collision behavior beyond current system semantics.

## Decisions

1. Decision: Grouping is a real filesystem move, not virtual parent mapping.
   Rationale: Directory structure remains the single source of truth; watcher and graph delta behavior already handles moved files naturally.
   Alternatives considered:
   - Virtual grouping map (rejected): avoids path changes but introduces dual truth and synchronization complexity.

2. Decision: Collapse by removing descendants from Cytoscape; expand by re-adding from graph model.
   Rationale: Guarantees rendering/perf win because hidden nodes are not in Cytoscape at all.
   Alternatives considered:
   - `display: none` on descendants (rejected): uncertain layout/render cost and ambiguous edge behavior.
   - Summary replacement nodes (rejected for v1): larger state-management surface.

3. Decision: No synthetic summary edges for collapsed descendants in v1.
   Rationale: Keeps behavior simple and predictable for first rollout.
   Alternatives considered:
   - Derive synthetic external edges from hidden children (deferred): improves topology visibility but adds complexity and edge bookkeeping risk.

4. Decision: Create recursive folder compounds only within loaded roots.
   Rationale: Supports true nested folder collapse while preventing ancestor/sibling explosion in the graph.
   Alternatives considered:
   - Full chain to `~/` (rejected): too many irrelevant folders rendered once ancestor levels are opened.

5. Decision: Sidebar is navigation; graph is loaded/expanded workspace.
   Rationale: Sidebar already scales for large trees. Graph should only contain content the user explicitly loaded or expanded.
   Alternatives considered:
   - Graph-only filesystem navigation (rejected): recreates existing sidebar concerns in a less scalable medium.

## Risks / Trade-offs

- [Collapsed folders hide external connectivity] -> Accept in v1 and revisit synthetic summary edges only if users report navigation loss.
- [Filesystem move can partially fail] -> Use transactional move flow with clear error reporting and best-effort rollback.
- [Large expand can reintroduce transient layout cost] -> Keep subfolders collapsed by default and apply existing large-graph performance guards.
- [Path changes may surface weak assumptions in downstream code] -> Treat move as delete+add consistently and test key workflows (selection, layout, edge sync).

## Migration Plan

1. Implement recursive folder chain creation and collapse state handling behind a feature flag.
2. Add context-menu grouping action that executes mkdir + move operations on disk.
3. Integrate sidebar folder-load behavior with new workspace rendering rules.
4. Validate with real vault sessions; then enable by default.
5. Rollback: disable the feature flag to restore existing folder-compound behavior.

## Open Questions

- Should collapse state persist across app restarts or only during session lifetime?
- What exact conflict policy should grouping use for destination filename collisions?
- Should agent-triggered grouping require user confirmation in all contexts, or support trusted automatic mode?
