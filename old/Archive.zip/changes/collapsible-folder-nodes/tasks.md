## 1. Recursive Folder Chain Foundation

- [ ] 1.1 Replace single-parent folder creation in `applyGraphDeltaToUI.ts` with `ensureFolderChain()` that materializes intermediate folders with correct Cytoscape parent links
- [ ] 1.2 Constrain chain creation to loaded root folders so ancestors above loaded roots are not auto-rendered
- [ ] 1.3 Add cleanup logic that prunes empty folder compounds recursively while preserving loaded-root folder nodes

## 2. Folder Collapse/Expand Mechanics

- [ ] 2.1 Introduce folder collapse state tracking keyed by folder node ID
- [ ] 2.2 Implement collapse action to remove descendant nodes and their edges from Cytoscape while leaving the folder node rendered with descendant count metadata
- [ ] 2.3 Implement expand action to re-add direct children from graph model and default newly visible subfolders to collapsed
- [ ] 2.4 Ensure graph delta application preserves collapse state and updates collapsed descendant counts

## 3. Folder Node Styling and Interaction

- [ ] 3.1 Update folder node styles to visually distinguish collapsed vs expanded state and show descendant counts
- [ ] 3.2 Add click/double-click behavior (or equivalent configured gesture) to toggle folder collapse state
- [ ] 3.3 Verify collapsed folders do not create synthetic summary edges and only rendered-node edges remain visible

## 4. Group Into Folder Filesystem Workflow

- [ ] 4.1 Add `Group into folder` multi-select context menu action in `getNodeMenuItems.ts`
- [ ] 4.2 Implement grouping command to create destination directory at nearest common ancestor and move selected markdown files into it
- [ ] 4.3 Integrate safe failure handling with best-effort rollback and user-visible error reporting for partial move failures
- [ ] 4.4 Validate watcher-driven delete/add graph deltas correctly remove old node IDs and add new node IDs after grouping

## 5. Sidebar-to-Graph Workspace Loading

- [ ] 5.1 Wire sidebar folder-load action to mount selected folders as top-level graph workspace roots
- [ ] 5.2 Ensure loaded roots render without ancestor-chain explosion and use recursive folder compounds only within each loaded root
- [ ] 5.3 Default subfolders to collapsed when first shown from root load or parent expansion

## 6. Agent and Integration Surface

- [ ] 6.1 Expose MCP/agent-side command path for creating folders and moving nodes using the same filesystem grouping backend
- [ ] 6.2 Add integration tests for collapse/expand behavior, recursive nesting, and grouping move flows (including failure cases)
- [ ] 6.3 Add regression tests for layout stability and edge visibility in collapsed vs expanded states
- [ ] 6.4 Roll out behind a feature flag and document rollback path to existing folder behavior
