## 1. Package Skeleton + Interfaces

- [ ] 1.1 Create `packages/agent-runtime/` with package.json, tsconfig.json, vitest config
- [ ] 1.2 Define `TerminalDataSink`, `UILaunchHook`, `RegistryObserver` adapter interfaces in `src/interfaces.ts`
- [ ] 1.3 Move zero-refactor files: `headlessAgentManager.ts`, `send-text-to-terminal.ts`, `terminal-output-buffer.ts`, `buildTerminalEnvVars.ts`, `global-budget-registry.ts`
- [ ] 1.4 Move stop gate files: `stopGateHookRunner.ts`, `stopGateAudit.ts`, `stopGateMultiSkill.ts`, `stopGateNoSkillFallback.ts`
- [ ] 1.5 Unit tests pass for moved files in isolation (no webapp imports)

## 2. Refactor Coupled Files

- [ ] 2.1 Refactor `terminal-manager.ts`: replace `WebContents` param with `TerminalDataSink` callback interface
- [ ] 2.2 Refactor `terminal-registry.ts`: replace `uiAPI.syncTerminals()` with `RegistryObserver` event emission
- [ ] 2.3 Refactor `spawnTerminalWithContextNode.ts`: make UI launch pluggable via `UILaunchHook` (no-op when absent)
- [ ] 2.4 Move refactored files to `packages/agent-runtime/src/`
- [ ] 2.5 Tests with mock adapters: spawn interactive terminal, verify data flows through sink; spawn headless, verify ring buffer capture

## 3. Move MCP Server

- [ ] 3.1 Move `mcp-server/` directory into `packages/agent-runtime/src/mcp-server/`
- [ ] 3.2 Wire graph tools (`create_graph`, `graph_structure`, `get_unseen_nodes_nearby`) to use `@vt/graph-db-client` for graph state access
- [ ] 3.3 Integration test: boot standalone agent-runtime, spawn headless agent, read_terminal_output, close_agent
- [ ] 3.4 Integration test: spawn interactive agent, send_message, verify PTY receives text

## 4. Standalone Binary

- [ ] 4.1 Create `bin/vt-agent-server.ts` — argv parsing (--vault, --port), boot agent-runtime with no-op adapters, write port file
- [ ] 4.2 Implement `/health` endpoint returning `{status, vault, pid}`
- [ ] 4.3 Implement SIGINT/SIGTERM handler: kill terminals, remove port file, exit 0
- [ ] 4.4 Implement exclusive file lock (`<vault>/.voicetree/agent-server.lock`) with stale-PID recovery
- [ ] 4.5 Manual smoke test: start server, curl /health, spawn agent via MCP client, read output, stop server

## 5. CLI Commands

- [ ] 5.1 Add `vt agent serve` command — starts agent-server in foreground, vault detection from cwd or --vault
- [ ] 5.2 Add auto-launch utility: detect running server via port file + /health ping, start if needed (exponential backoff up to 5s)
- [ ] 5.3 Add `vt agent spawn` command — --task, --headless, --parent-node, --depth-budget flags
- [ ] 5.4 Add `vt agent send` command — terminalId + message args
- [ ] 5.5 Add `vt agent list` command — table output + --json flag
- [ ] 5.6 Add `vt agent wait` command — --all, --timeout flags
- [ ] 5.7 Add `vt agent close` command — --all flag
- [ ] 5.8 Add `vt agent output` command — --last, --follow flags
- [ ] 5.9 CLI e2e tests: spawn → send → wait → output → close lifecycle

## 6. Webapp Adapter Integration

- [ ] 6.1 Create `webapp/src/shell/edge/main/agent-runtime-bridge.ts` — instantiate agent-runtime with Electron adapters (WebContents sink, UI launch hook, IPC sync observer)
- [ ] 6.2 Replace terminal/ imports throughout webapp with `@vt/agent-runtime` + bridge
- [ ] 6.3 Update IPC handlers (`ipc-terminal-handlers.ts`) to delegate to agent-runtime instance
- [ ] 6.4 Delete moved files from `webapp/src/shell/edge/main/terminals/` and `mcp-server/`
- [ ] 6.5 Verify: existing Playwright e2e tests pass (interactive terminals, headless agents, MCP tools)

## 7. Cleanup

- [ ] 7.1 Add ESLint rule banning direct terminal/mcp-server imports from webapp (must use bridge)
- [ ] 7.2 Remove dead code, unused imports
- [ ] 7.3 Update CLAUDE.md runtime architecture section to document agent-runtime package
- [ ] 7.4 Update `.mcp.json` auto-generation to point at standalone server when Electron is not running
