## Why

The MCP agent-control surface (spawn_agent, send_message, wait_for_agents, close_agent, etc.) and the terminal runtime that backs it are locked inside the Electron webapp process. CLI and external tools cannot spawn or control agents without a running desktop app. The `decouple-ui-from-graph-server` spec (Decision 8) explicitly deferred this as a "separate refactor" — this is that refactor. BF-188 proved the pattern works: `vt-headless serve` runs the data-layer MCP standalone. Now we apply the same pattern to agent control.

## What Changes

- **New package `@vt/agent-runtime`** — extracts terminal management, agent spawning, budget registry, stop gates, and the full MCP server out of `webapp/src/shell/edge/main/`. Runs without Electron.
- **3 interface decouplings:**
  - `TerminalManager.spawn()`: callback `(data: Buffer) => void` replaces `WebContents`
  - `spawnTerminalWithContextNode()`: pluggable UI launch hook (no-op in headless)
  - `terminal-registry`: EventEmitter replaces `uiAPI.syncTerminals()`
- **New binary `vt-agent-server`** — starts the agent-control MCP server standalone on an ephemeral port, writing discovery to `<vault>/.voicetree/agent-server.port`.
- **CLI parity commands** — `vt agent serve`, `vt agent spawn`, `vt agent send`, `vt agent list`, `vt agent wait`, `vt agent close`.
- **Webapp becomes a consumer** of `@vt/agent-runtime`, providing Electron adapter implementations (WebContents bridge for PTY data, UI launch bridge for interactive terminals).
- Existing MCP tools unchanged in behaviour — agents see no difference.

## Capabilities

### New Capabilities

- `agent-runtime`: Standalone agent-control runtime package. Owns terminal lifecycle (PTY + headless), spawn orchestration, budget management, stop gates, and the agent-control MCP server. Runs without Electron. Single vault per process.
- `cli-agent-control`: CLI commands for headless agent orchestration — spawn agents, send messages, read output, wait for completion, close agents. All routed through the agent-runtime MCP server.

### Modified Capabilities

- `graph-db-server`: The existing `vt-graphd` daemon gains awareness of the agent-runtime server for coordinated port discovery (both write to `.voicetree/`). No spec-level requirement changes — just coordination.

## Impact

- **New package**: `packages/agent-runtime/` (~2700 LOC moved from webapp, 3 interfaces refactored)
- **New binary**: `packages/agent-runtime/bin/vt-agent-server.ts`
- **Modified**: `webapp/src/shell/edge/main/terminals/` — replaced with imports from `@vt/agent-runtime` + Electron adapter layer
- **Modified**: `webapp/src/shell/edge/main/mcp-server/` — moved to `@vt/agent-runtime`; webapp re-exports or starts it
- **Modified**: `packages/graph-tools/` — CLI gains `agent` subcommand group
- **Dependencies**: `node-pty` moves from webapp devDeps to `@vt/agent-runtime` deps
- **No user-visible behaviour change** for desktop app users
