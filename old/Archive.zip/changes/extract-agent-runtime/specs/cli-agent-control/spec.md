## ADDED Requirements

### Requirement: vt agent serve
The CLI SHALL provide `vt agent serve` to explicitly start the agent-runtime server for the current vault.

#### Scenario: Manual server start
- **WHEN** user runs `vt agent serve` in a directory containing `.voicetree/`
- **THEN** the agent-server starts, prints the bound port, and runs in foreground until interrupted

#### Scenario: Vault detection from cwd
- **WHEN** user runs `vt agent serve` without `--vault` flag
- **THEN** the CLI finds the nearest ancestor directory containing `.voicetree/` and uses it as the vault

#### Scenario: Explicit vault path
- **WHEN** user runs `vt agent serve --vault /path/to/vault`
- **THEN** the server starts for the specified vault regardless of cwd

### Requirement: vt agent spawn
The CLI SHALL provide `vt agent spawn` to spawn an agent via the agent-runtime server.

#### Scenario: Spawn headless agent
- **WHEN** user runs `vt agent spawn --task "fix the bug" --headless`
- **THEN** the CLI auto-launches agent-server if needed, spawns a headless agent, and prints the terminal ID

#### Scenario: Spawn interactive agent
- **WHEN** user runs `vt agent spawn --task "implement feature" --parent-node <id>`
- **THEN** the CLI spawns an interactive PTY agent, prints the terminal ID, and the agent begins working

#### Scenario: Auto-launch server
- **WHEN** `vt agent spawn` is called and no agent-server is running
- **THEN** the CLI starts the agent-server in the background, waits for `/health` to respond (up to 5s with exponential backoff), then executes the spawn

### Requirement: vt agent send
The CLI SHALL provide `vt agent send` to send a message to a running interactive agent.

#### Scenario: Send message to interactive agent
- **WHEN** user runs `vt agent send <terminalId> "check the test output"`
- **THEN** the message is injected into the agent's PTY as keyboard input and the CLI prints success

#### Scenario: Send to headless agent rejected
- **WHEN** user runs `vt agent send <headlessTerminalId> "hello"`
- **THEN** the CLI prints an error: headless agents cannot receive messages

### Requirement: vt agent list
The CLI SHALL provide `vt agent list` to show all running agents.

#### Scenario: List with running agents
- **WHEN** user runs `vt agent list` with 3 agents running
- **THEN** the CLI prints a table with columns: terminalId, agentName, status (active/idle), headless (y/n), taskNode

#### Scenario: JSON output
- **WHEN** user runs `vt agent list --json`
- **THEN** output is valid JSON array of agent records

### Requirement: vt agent wait
The CLI SHALL provide `vt agent wait` to block until specified agents complete or go idle.

#### Scenario: Wait for single agent
- **WHEN** user runs `vt agent wait <terminalId>`
- **THEN** the CLI blocks until the agent exits or goes idle, then prints the final status

#### Scenario: Wait for all agents
- **WHEN** user runs `vt agent wait --all`
- **THEN** the CLI blocks until all agents exit or go idle

#### Scenario: Timeout
- **WHEN** user runs `vt agent wait <id> --timeout 60`
- **THEN** if the agent hasn't finished in 60 seconds, the CLI exits with a timeout error

### Requirement: vt agent close
The CLI SHALL provide `vt agent close` to terminate a running agent.

#### Scenario: Close agent gracefully
- **WHEN** user runs `vt agent close <terminalId>`
- **THEN** the agent's terminal is killed, stop gate audit runs, and the CLI prints the result

#### Scenario: Close all agents
- **WHEN** user runs `vt agent close --all`
- **THEN** all running agents are closed sequentially and results printed

### Requirement: vt agent output
The CLI SHALL provide `vt agent output` to read an agent's terminal output buffer.

#### Scenario: Read last N characters
- **WHEN** user runs `vt agent output <terminalId> --last 2000`
- **THEN** the CLI prints the last 2000 characters from the agent's ring buffer

#### Scenario: Follow mode
- **WHEN** user runs `vt agent output <terminalId> --follow`
- **THEN** the CLI continuously prints new output as it arrives (like `tail -f`)
