## ADDED Requirements

### Requirement: Standalone agent-runtime process
The agent-runtime SHALL run as a standalone process without Electron, serving the agent-control MCP server on localhost.

#### Scenario: Boot without Electron
- **WHEN** `vt-agent-server --vault /path/to/vault` is executed
- **THEN** the process starts, binds to an ephemeral port on 127.0.0.1, and writes the port number to `<vault>/.voicetree/agent-server.port`

#### Scenario: Health endpoint
- **WHEN** a client sends GET to `/health` on the agent-server port
- **THEN** the server responds with 200 and `{"status": "ok", "vault": "<path>", "pid": <number>}`

#### Scenario: Graceful shutdown
- **WHEN** the process receives SIGINT or SIGTERM
- **THEN** it kills all managed terminals, removes the port file, and exits with code 0

### Requirement: MCP tool parity
The agent-runtime MCP server SHALL expose the same tools with the same schemas as the current webapp MCP server: `spawn_agent`, `list_agents`, `wait_for_agents`, `close_agent`, `send_message`, `read_terminal_output`, `get_unseen_nodes_nearby`, `create_graph`, `graph_structure`.

#### Scenario: Tool schema unchanged
- **WHEN** an agent calls `spawn_agent` with `{task, parentNodeId, headless, depthBudget}` against the standalone server
- **THEN** the response shape matches the existing webapp MCP server response exactly

#### Scenario: All tools available
- **WHEN** an MCP client connects and lists tools
- **THEN** all 9 agent-control tools are present with unchanged parameter schemas

### Requirement: PTY terminal spawning via adapter
The agent-runtime SHALL spawn interactive PTY terminals using node-pty, pushing data through a `TerminalDataSink` interface rather than directly to Electron WebContents.

#### Scenario: Interactive agent spawn in standalone mode
- **WHEN** `spawn_agent` is called with `headless: false` in standalone mode (no UI adapter)
- **THEN** a PTY process is created, data flows to the configured TerminalDataSink, and `send_message` can write to the PTY's stdin

#### Scenario: Interactive agent spawn with Electron adapter
- **WHEN** `spawn_agent` is called with `headless: false` while the Electron adapter is configured
- **THEN** PTY data flows through the adapter to WebContents.send() and the terminal appears in the UI

### Requirement: Headless agent spawning
The agent-runtime SHALL spawn headless agents using child_process.spawn with ring-buffer output capture, identical to current behaviour.

#### Scenario: Headless agent lifecycle
- **WHEN** `spawn_agent` is called with `headless: true`
- **THEN** a child process is spawned, stdout+stderr captured in an 8KB ring buffer, and `read_terminal_output` returns the buffer contents

#### Scenario: send_message blocked for headless
- **WHEN** `send_message` targets a headless agent
- **THEN** an error is returned indicating headless agents cannot receive messages

### Requirement: Port discovery coexistence
The agent-runtime port file SHALL coexist with the graph daemon port file without collision.

#### Scenario: Both servers running
- **WHEN** both `vt-graphd` and `vt-agent-server` are running for the same vault
- **THEN** `<vault>/.voicetree/graphd.port` and `<vault>/.voicetree/agent-server.port` exist independently with different port numbers

### Requirement: Single instance per vault
The agent-runtime SHALL enforce single-instance-per-vault via an exclusive file lock.

#### Scenario: Second instance rejected
- **WHEN** a second `vt-agent-server` attempts to start for the same vault
- **THEN** it detects the lock, verifies liveness of the existing process, and exits with an error message pointing to the running instance

#### Scenario: Stale lock recovery
- **WHEN** a lock file exists but the PID is dead
- **THEN** the new instance removes the stale lock and starts normally

### Requirement: Webapp adapter integration
The webapp SHALL import `@vt/agent-runtime` and provide Electron-specific adapter implementations without behaviour change.

#### Scenario: Desktop app unchanged
- **WHEN** the Electron app boots with the new agent-runtime integration
- **THEN** interactive terminals appear in the UI, headless agents work, MCP tools respond — all identical to pre-extraction behaviour

#### Scenario: IPC handlers delegate to runtime
- **WHEN** the renderer sends `terminal:spawn` / `terminal:write` / `terminal:resize` / `terminal:kill` via IPC
- **THEN** the IPC handler delegates to the agent-runtime instance (not reimplemented in webapp)
