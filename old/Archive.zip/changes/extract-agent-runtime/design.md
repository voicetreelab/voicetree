## Context

Terminal/agent-control code lives in `webapp/src/shell/edge/main/terminals/` (27 files, ~2700 LOC) and `webapp/src/shell/edge/main/mcp-server/` (~11 tool files + server). The code is already well-factored: ~70% has zero Electron imports. Three thin coupling points bind it to the desktop app:

1. `terminal-manager.ts` — `spawn()` takes `WebContents` to push PTY data via IPC
2. `spawnTerminalWithContextNode.ts` — calls `uiAPI.launchTerminalOntoUI()` for interactive agents
3. `terminal-registry.ts` — calls `uiAPI.syncTerminals()` after state mutations

The `decouple-ui-from-graph-server` spec (Decision 8) flagged this extraction but deferred it. BF-188 (`vt-headless serve`) proved the standalone-server pattern. The graph daemon (`vt-graphd`) already owns graph state independently — this change does the same for agent lifecycle.

Constraints:
- Port 3002 reserved for orchestration MCP; must not be used.
- `vt-graphd` already writes `.voicetree/graphd.port` for discovery — agent-runtime must coexist.
- Existing MCP tool contracts (parameter schemas, response shapes) must not change — agents depend on them.
- `node-pty` requires native compilation; package must handle this cleanly.

## Goals / Non-Goals

**Goals:**
- Agent-control MCP server (`spawn_agent`, `list_agents`, `wait_for_agents`, `close_agent`, `send_message`, `read_terminal_output`, `get_unseen_nodes_nearby`, `create_graph`, `graph_structure`) runnable as a standalone process without Electron.
- CLI commands for the full agent orchestration loop.
- Webapp unchanged in behaviour — it imports `@vt/agent-runtime` and provides Electron-specific adapters.
- One vault per agent-server process (same constraint as `vt-graphd`).
- Auto-launch: first CLI command starts the server if not running.

**Non-Goals:**
- Multi-vault serving from one process.
- Remote/network agent control (localhost:127.0.0.1 only).
- Merging with `vt-graphd` (separate process, separate concern — agent lifecycle ≠ graph state).
- Replacing xterm.js rendering in the desktop app.
- Voice-to-text from CLI.

## Decisions

1. **New package `packages/agent-runtime/` — not merged into `graph-tools` or `graph-db-server`.**
   Rationale: agent lifecycle (PTYs, spawn budgets, stop gates) is orthogonal to graph parsing and graph state serving. Keeping them separate means `@vt/graph-model` stays pure (tests, webworkers, CI) and `vt-graphd` stays focused on data. Native dep `node-pty` stays contained.
   Alternatives: bake into graph-tools (rejected — pollutes pure package with native dep); bake into graph-db-server (rejected — conflates data serving with process management).

2. **Adapter pattern for Electron decoupling. Three interfaces:**
   ```ts
   interface TerminalDataSink {
     onData(terminalId: string, data: Buffer): void;
     onExit(terminalId: string, code: number): void;
   }
   
   interface UILaunchHook {
     launchTerminalOntoUI?(terminalId: string, meta: TerminalMeta): void;
   }
   
   interface RegistryObserver {
     onTerminalsChanged(terminals: TerminalRecord[]): void;
   }
   ```
   Headless mode passes no-op/event-emitter implementations. Webapp passes Electron bridges. This inverts the dependency — runtime doesn't know about Electron; Electron knows about runtime.
   Alternatives: dependency injection container (rejected — overkill for 3 interfaces); conditional imports (rejected — couples runtime to optional Electron dep).

3. **Transport: same StreamableHTTP + MCP SDK pattern as existing server.**
   Rationale: zero migration cost for agents. Same URL shape (`/mcp`), same tool schemas, same per-request McpServer pattern. Agents' `.mcp.json` just points to a different port.
   Alternatives: gRPC (rejected — agents use MCP SDK); raw REST (rejected — would require rewriting all tool implementations).

4. **Port discovery: `<vault>/.voicetree/agent-server.port` + PID liveness check.**
   Rationale: mirrors `vt-graphd` pattern (`graphd.port`). Atomic write (tmp + rename). CLI retries with exponential backoff up to 5s. Liveness via `/health` ping + PID file.
   Alternatives: fixed port (rejected — collision with multiple vaults); Unix socket (rejected — Windows compat).

5. **Auto-launch from CLI: first `vt agent <cmd>` starts server if not running.**
   Rationale: UX. User runs `vt agent spawn --task "fix bug"` cold and it works. Same pattern as `vt-graphd` auto-launch from `vt vault` commands.
   Alternatives: require explicit `vt agent serve` first (rejected — friction).

6. **Graph tools (`create_graph`, `graph_structure`, `get_live_state`) stay in the agent-runtime MCP server for now.**
   Rationale: agents expect a single MCP endpoint with all tools. Splitting graph tools to `vt-graphd` and agent tools to agent-runtime would require agents to configure two MCP servers. Defer split to a future "unified MCP router" change. Agent-runtime calls `vt-graphd` client internally for graph operations.
   Alternatives: split immediately (rejected — breaks agent .mcp.json assumptions); proxy all through vt-graphd (rejected — conflates concerns in the wrong direction).

7. **Webapp integration: thin adapter file in `webapp/src/shell/edge/main/agent-runtime-bridge.ts`.**
   Rationale: single file that instantiates `@vt/agent-runtime` with Electron adapters (WebContents sink, UI launch hook, IPC sync observer). Replaces the 27-file terminals/ directory with imports. IPC handlers stay in webapp but delegate to the runtime.
   Alternatives: keep terminals/ directory and import selectively (rejected — leaves dead code and split ownership).

8. **Sequencing: can run in parallel with remaining `decouple-ui-from-graph-server` work.**
   Rationale: this change touches `terminals/` and `mcp-server/` which are disjoint from the graph-state files that `vt-graphd` touches. No merge conflicts expected.

## Risks / Trade-offs

- **`node-pty` native compilation in a new package.** → Mitigation: `@vt/agent-runtime` inherits the same build tooling (electron-rebuild / prebuild) already used by webapp. CI matrix already handles this.
- **Two servers per vault (`vt-graphd` + agent-server) = two processes.** → Acceptable. They serve orthogonal concerns. Could merge later if overhead matters, but localhost processes are cheap.
- **Agents currently expect one MCP endpoint.** → Agent-runtime keeps all tools (including graph tools via internal client call to vt-graphd). No agent-visible change.
- **Interactive terminal users in desktop app see no regression?** → Adapter pattern preserves exact same PTY data flow. WebContents.send() still called, just via the adapter instead of directly.
- **Stop gate audit reads graph nodes — needs graph access.** → Agent-runtime depends on `@vt/graph-db-client` to read graph state from `vt-graphd`. If graphd isn't running, stop gate degrades gracefully (skip audit, log warning).
- **send_message to headless agents is already blocked.** → No change needed. The guard stays in `sendMessageTool.ts`.

## Migration Plan

1. **Phase 1 — Package skeleton + interfaces.** Create `packages/agent-runtime/`, define the 3 adapter interfaces, move `headlessAgentManager.ts` + `send-text-to-terminal.ts` + `terminal-output-buffer.ts` + `buildTerminalEnvVars.ts` (zero-refactor files). Unit tests pass in isolation.
2. **Phase 2 — Refactor coupled files.** Refactor `terminal-manager.ts` (callback), `terminal-registry.ts` (EventEmitter), `spawnTerminalWithContextNode.ts` (pluggable UI hook). Move to package. Tests with mock adapters.
3. **Phase 3 — Move MCP server.** Move `mcp-server/` into `@vt/agent-runtime`. Wire graph tools to call `@vt/graph-db-client` internally. Integration tests: spawn headless agent via standalone server, read output, close.
4. **Phase 4 — Standalone binary.** `bin/vt-agent-server.ts` — boots agent-runtime with no-op adapters, writes port file, handles SIGINT. Manual smoke test.
5. **Phase 5 — CLI commands.** `vt agent serve|spawn|send|list|wait|close`. Auto-launch logic. CLI e2e tests.
6. **Phase 6 — Webapp adapter.** Create `agent-runtime-bridge.ts` in webapp. Replace terminals/ imports. Delete moved files. Existing Playwright tests pass.
7. **Phase 7 — Cleanup.** Remove dead code, add ESLint rule banning direct terminal imports from webapp (must go through bridge).

Rollback: phases 1–5 are purely additive (no webapp behaviour change). Phase 6 is the swap — single-commit revertable.

## Open Questions

- Should agent-runtime auto-start `vt-graphd` if not running (for graph tool calls)? **Proposal:** yes, same auto-launch pattern. Confirm during Phase 3.
- Should `vt agent serve` and `vt-graphd` share a single auto-launch mechanism? **Proposal:** shared utility in `@vt/graph-db-client` (`ensureDaemonRunning(type, vaultPath)`). Confirm during Phase 5.
- Do we need a unified "VoiceTree daemon manager" that starts both? **Deferred.** Not needed for v1; add when UX friction surfaces.
