## ADDED Requirements

### Requirement: The system SHALL maintain shared order and position state across paper and live modes
The system SHALL maintain a shared lifecycle model for orders, fills, and positions regardless of whether execution is simulated or live.

#### Scenario: Order lifecycle updates position state
- **WHEN** an order transitions through proposal, fill, partial fill, or close events
- **THEN** the system updates the corresponding order and position state in the shared ledger
- **THEN** operators can inspect open exposure and realized outcomes from one consistent state model

### Requirement: The system SHALL reconcile live execution state against wallet activity and price history
The system SHALL use wallet activity and historical price data to hydrate live execution outcomes and portfolio metrics.

#### Scenario: Wallet activity updates execution state
- **WHEN** reconciliation finds wallet activity and price-history records corresponding to a submitted live order
- **THEN** the system updates the order and position state with matched activity, fill timing, and price context
- **THEN** realized and unrealized PnL metrics are recomputed from the reconciled state

### Requirement: The system SHALL surface reconciliation exceptions
The system SHALL record and expose exceptions when expected execution state and observed market or wallet data do not agree.

#### Scenario: Unmatched execution is flagged
- **WHEN** an expected live order cannot be matched to wallet activity or the observed fill size materially differs from expected state
- **THEN** the system records a reconciliation exception tied to the relevant signal or order
- **THEN** the exception remains visible until the operator resolves or dismisses it
