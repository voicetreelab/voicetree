## ADDED Requirements

### Requirement: The system SHALL validate signals before paper execution
The system SHALL validate canonical execution signals before paper execution, including signal completeness, quote freshness, and sizing-policy compliance.

#### Scenario: Valid signal is accepted for paper execution
- **WHEN** a canonical signal has all required market references, a fresh quote snapshot, and sizing within policy
- **THEN** the paper executor accepts the signal
- **THEN** the system creates proposed paper orders linked to that signal

#### Scenario: Invalid signal is rejected before simulation
- **WHEN** a canonical signal is stale, incomplete, duplicated, or exceeds configured sizing policy
- **THEN** the paper executor rejects the signal
- **THEN** the system records the rejection reason without creating simulated fills

### Requirement: The system SHALL record paper orders, fills, and positions in the shared execution ledger
The system SHALL record paper-trading lifecycle events in the same ledger model used for live execution.

#### Scenario: Paper order updates shared state
- **WHEN** the paper executor simulates an accepted trade
- **THEN** the system records the proposed order, simulated fill details, and resulting position updates in the shared execution ledger
- **THEN** the resulting state is queryable alongside any later live-execution records

### Requirement: Paper execution MUST operate without live trading credentials
The system MUST allow paper execution to run without wallet credentials or live-order adapters.

#### Scenario: Paper mode runs with live mode disabled
- **WHEN** the operator runs the executor in paper mode without configured live credentials
- **THEN** the system completes validation, quote snapshotting, and simulated state updates
- **THEN** no live order submission is attempted
