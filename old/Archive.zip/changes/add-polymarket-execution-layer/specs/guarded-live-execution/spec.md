## ADDED Requirements

### Requirement: The system SHALL require explicit operator approval before live order submission
The system SHALL prevent live order submission until an operator has explicitly approved the proposed trade.

#### Scenario: Unapproved order cannot go live
- **WHEN** a signal has produced a proposed live order but no operator approval has been recorded
- **THEN** the system keeps the order in a pending approval state
- **THEN** no live submission is attempted

### Requirement: The system SHALL enforce live risk controls before submission
The system SHALL enforce configured risk controls before submitting any live order, including dry-run defaults, total exposure limits, per-market caps, and kill-switch status.

#### Scenario: Risk limit breach blocks submission
- **WHEN** a proposed live order would violate a configured portfolio limit or per-market exposure cap
- **THEN** the system blocks live submission
- **THEN** the operator receives the blocking reason in the order status

### Requirement: The system SHALL support a kill switch for live execution
The system SHALL provide a kill switch that blocks new live submissions until explicitly cleared.

#### Scenario: Kill switch halts live execution
- **WHEN** the kill switch is active
- **THEN** the system rejects new live submission attempts
- **THEN** existing paper-mode workflows remain available for continued testing and review

### Requirement: The system MUST default to dry-run when live prerequisites are missing
The system MUST default to dry-run behavior unless live mode, credentials, and operator approval prerequisites are all satisfied.

#### Scenario: Missing live prerequisites force dry-run
- **WHEN** live credentials are absent or live mode has not been explicitly enabled
- **THEN** the system records intended orders in dry-run form only
- **THEN** no external order-routing call is made
