## ADDED Requirements

### Requirement: The system SHALL persist canonical execution signals
The system SHALL persist each Polymarket trade opportunity as a canonical execution signal with stable identifiers and the minimum fields needed for audit and execution, including `signal_id`, `generated_at`, `market_url`, `market_slug`, `token_id`, `outcome`, `side`, `model_prob`, `market_prob`, `edge`, `size_rule`, `suggested_notional`, and `thesis_ref`.

#### Scenario: Store a manually selected market signal
- **WHEN** an operator or upstream analysis workflow submits a signal for a specific Polymarket market and token
- **THEN** the system stores one canonical execution-signal record with the required identifiers, market references, probability inputs, and sizing guidance
- **THEN** the stored signal can be referenced by later paper or live execution records

### Requirement: The system MUST reject execution signals without concrete market references
The system MUST reject any execution signal that does not identify a specific market and tradable token.

#### Scenario: Missing token reference blocks signal intake
- **WHEN** a submitted signal omits `token_id`, `market_slug`, or side-specific trade intent
- **THEN** the system rejects the signal as invalid
- **THEN** no execution request is created from that signal

### Requirement: The system SHALL preserve signal lineage across execution attempts
The system SHALL preserve the relationship between an execution signal and all proposed, approved, simulated, or live orders derived from it.

#### Scenario: Orders link back to originating signal
- **WHEN** the executor creates one or more orders from an accepted signal
- **THEN** each order record references the originating `signal_id`
- **THEN** operators can trace later fills, positions, and reconciliation events back to the original signal
