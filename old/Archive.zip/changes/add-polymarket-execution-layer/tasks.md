## 1. Canonical Signals And Ledger

- [ ] 1.1 Define the canonical execution-signal schema and validation rules, including required market references, probability fields, sizing inputs, thesis links, and lifecycle identifiers
- [ ] 1.2 Implement the durable execution ledger schema for signals, orders, fills, positions, reconciliation events, and risk events
- [ ] 1.3 Add repositories or access helpers that create, read, and update signal and execution state idempotently

## 2. Paper Trading Executor

- [ ] 2.1 Implement the shared executor interface that accepts canonical signals and produces proposed orders plus lifecycle events
- [ ] 2.2 Build paper-execution mode with quote snapshotting, simulated fills, and portfolio-state updates in the shared ledger
- [ ] 2.3 Add validation for stale quotes, missing token references, duplicate signals, and out-of-policy sizes before paper execution proceeds

## 3. Reconciliation And Portfolio State

- [ ] 3.1 Implement order, fill, and position lifecycle tracking on top of the shared ledger
- [ ] 3.2 Integrate wallet-activity and price-history reconciliation to hydrate live execution state and compute realized and unrealized PnL
- [ ] 3.3 Surface reconciliation exceptions for unmatched activity, size drift, stale positions, and missing fill confirmation

## 4. Guarded Live Execution

- [ ] 4.1 Implement an operator approval workflow that turns proposed orders into approved or rejected live-execution requests
- [ ] 4.2 Add pre-submit risk controls for dry-run defaults, per-market exposure caps, total portfolio limits, and kill-switch enforcement
- [ ] 4.3 Implement a live-order adapter behind the shared executor interface and keep it disabled until approval and risk checks pass

## 5. Verification And Operator Workflow

- [ ] 5.1 Add tests for canonical signal validation, paper execution state transitions, reconciliation flows, and live-execution gating
- [ ] 5.2 Document the operator runbook for manual market selection, paper-trading review, approval flow, kill-switch use, and rollback to dry-run mode
- [ ] 5.3 Verify that a future market-discovery producer can emit the same signal schema without changing executor or reconciliation interfaces
