## Context

The current repo already has reusable Polymarket building blocks on the research side:
- market and token lookup via existing Polymarket parsing/fetch scripts
- model-versus-market probability outputs and Kelly-style sizing artifacts
- validated wallet reconciliation via `hash -> /activity transactionHash -> asset -> prices-history`

What it does not have is a durable execution system. There is no local auth, signing, order submission, cancellation, fill handling, or position-state module that can safely consume the current prediction outputs. The existing signal history is mostly markdown-first, which is useful for analysis but weak for execution-state management.

This design targets a single-operator, human-supervised MVP. Manual market selection remains upstream of the executor. The execution layer starts only after a specific market and token have already been chosen and the existing analysis pipeline has produced a trade thesis.

## Goals / Non-Goals

**Goals:**
- Normalize current Polymarket analysis outputs into a canonical execution signal.
- Persist signals, orders, fills, positions, and reconciliation events in a durable local store.
- Use one shared execution ledger for both paper and live modes so paper trading exercises the same state transitions intended for production.
- Reconcile execution state against wallet activity and price history to support audit, monitoring, and post-trade review.
- Require explicit operator approval and hard risk controls before any live order submission.
- Keep the interface stable so future market-discovery automation can emit the same signal shape.

**Non-Goals:**
- Automated market discovery or autonomous market selection in v1.
- Unattended live trading without human approval.
- Advanced execution strategies such as slicing, smart routing, or arbitrage.
- Multi-operator coordination, remote deployment, or exchange-agnostic abstractions.

## Decisions

1. Decision: Use a canonical, immutable execution-signal record as the boundary between analysis and execution.
   Rationale: Existing outputs are fragmented across markdown, JSON, and scripts. A normalized signal contract gives the executor one stable intake surface and makes later automation easier.
   Alternatives considered:
   - Keep markdown-first handoff (rejected): too ambiguous for validation, replay, and automated state tracking.
   - Let each producer define its own payload (rejected): guarantees drift and brittle execution logic.

2. Decision: Persist execution state in a local SQLite-backed ledger with append-oriented records for `signals`, `orders`, `fills`, `positions`, `reconciliation_events`, and `risk_events`.
   Rationale: The MVP is single-operator and local-first, but still needs durable, queryable state across paper and live modes. SQLite is sufficient without introducing service infrastructure.
   Alternatives considered:
   - Flat JSON or JSONL files only (rejected): weak for joins, idempotency, and operator queries.
   - Remote database first (rejected): unnecessary deployment complexity for the MVP.

3. Decision: Make paper execution and live execution share one executor interface and one state model.
   Rationale: Paper mode should exercise the same validations, order construction, lifecycle updates, and reconciliation hooks that live mode will rely on later.
   Alternatives considered:
   - Separate paper simulator and live executor implementations (rejected): high risk of divergent behavior.

4. Decision: Treat reconciliation as a first-class subsystem, not a reporting afterthought.
   Rationale: The validated wallet-activity and price-history path is the strongest existing execution primitive in the repo. It should hydrate fills, positions, and drift signals rather than only support ex-post analysis.
   Alternatives considered:
   - Rely only on submit-time state and optimistic updates (rejected): too fragile once live trading begins.

5. Decision: Require an operator approval queue before any live order submission.
   Rationale: The user explicitly wants a human-supervised MVP. Approval preserves operator judgment around stale news, market microstructure, and ambiguous token mappings while still allowing the rest of the pipeline to be automated.
   Alternatives considered:
   - Fully automatic live routing (rejected): exceeds the trust boundary justified by current infrastructure.
   - Manual order entry outside the system (rejected): loses the auditable signal-to-order chain.

6. Decision: Keep market discovery out of the execution layer and require concrete market references in every signal.
   Rationale: The executor should consume `market_slug`, `token_id`, `outcome`, and side-specific intent, not search for candidates itself. This keeps v1 bounded and makes later discovery integration cleaner.
   Alternatives considered:
   - Let the executor pick markets from a watchlist (rejected): mixes discovery with execution and expands scope too early.

## Risks / Trade-offs

- [No local signing or order-routing path exists yet] -> Isolate live submission behind an adapter interface and complete paper mode plus reconciliation before enabling live orders.
- [Quote staleness can make approved orders unsafe] -> Require fresh quote snapshots and final risk checks immediately before live submission.
- [Wallet activity may not map perfectly to intended orders] -> Store intent IDs on proposed orders and surface unmatched or size-divergent executions as reconciliation exceptions.
- [SQLite is local-first and single-writer oriented] -> Accept for MVP; keep schema and repositories narrow so storage can be replaced later if needed.
- [Manual market selection reduces throughput] -> Accept as a deliberate safety trade-off for v1 and preserve producer interfaces for later discovery automation.

## Migration Plan

1. Implement the canonical signal store and execution ledger schema.
2. Add paper execution on top of the shared executor interface and ledger.
3. Integrate reconciliation using the validated wallet-activity and price-history path.
4. Add approval workflow, risk engine, and kill-switch controls around a live-order adapter.
5. Keep live mode disabled by default until paper-trading and reconciliation flows are stable.
6. Later, add automated market discovery as a separate producer that emits the same canonical signal records.

## Open Questions

- Which Polymarket auth/signing client should back the live-order adapter?
- Should the MVP support only one order type initially, or both aggressive and passive orders?
- What operator surface is most practical for approvals in this repo: CLI, markdown queue, or a simple local UI?
