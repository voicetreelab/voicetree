## Why

Existing Polymarket work in this repo can already identify markets, compute `model_prob` versus `market_prob`, suggest Kelly-style sizing, and reconcile historical wallet activity. What is missing is the execution boundary that turns those outputs into durable, auditable trades without jumping straight to fully autonomous live trading.

This change defines the first buildable execution layer: canonical signals, paper trading, reconciliation, and operator-approved live execution. It is the smallest proposal that can convert the current research stack into a human-supervised trading system while keeping automated market discovery explicitly out of scope for v1.

## What Changes

- Define a canonical execution-signal contract and durable store for manually selected Polymarket trade intents, including market/token references, probability inputs, sizing guidance, thesis links, and lifecycle metadata.
- Add a paper-trading executor that validates signals, snapshots market quotes, records simulated orders and fills, and updates portfolio state using the same ledger model intended for live trading.
- Add execution-state reconciliation that joins wallet activity and historical price data to track fills, positions, realized and unrealized PnL, and drift between expected and observed execution state.
- Add guarded live execution that requires explicit operator approval and enforces dry-run defaults, exposure limits, per-market caps, and a kill switch before any live order submission.
- Preserve a clean producer/consumer boundary so a later automated market-discovery layer can emit the same signal shape without changing the execution interfaces.
- Keep manual market selection as a deliberate v1 constraint; this proposal does not automate opportunity discovery or autonomous trade selection.

## Capabilities

### New Capabilities
- `execution-signals`: Canonical signal schema and persistence for manually selected Polymarket trade intents.
- `paper-trading-executor`: Shared paper-execution flow that validates signals, simulates fills, and records order and portfolio state.
- `execution-state-reconciliation`: Portfolio, order, and fill tracking that reconciles execution state against wallet activity and price history.
- `guarded-live-execution`: Operator-approved live order submission with dry-run defaults, risk checks, and kill-switch controls.

### Modified Capabilities

## Impact

- New execution-layer module(s) to sit between existing Polymarket prediction outputs and any future live trading path
- Existing Polymarket data and sizing utilities under `workflows/workflows/analysis/estimate_probability/polymarket-phase1/` and `workflows/workflows/old/polymarket-prediction-modeling*`
- Wallet-activity and historical-price reconciliation workflows already validated in the current voicetree context
- Local operator workflow for approving signals, inspecting paper results, and enabling guarded live execution
- Future market-discovery automation, which will need to emit the same `execution-signals` contract but remains follow-on work
