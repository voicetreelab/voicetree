## Context

Today's render flow (post-BF-L5-202b):

```
main daemon ──GraphDelta──▶ renderer subscribeToGraphUpdates
                              │
                              ▼
                            projectDelta(delta)
                              │  (folds delta into rendererStateMirror,
                              │   then calls project(buildStateFromMirror()))
                              ▼
                            applyGraphDeltaToUI(cy, ElementSpec)
                              │  (reconciles ElementSpec into cytoscape)
                              ▼
                            cytoscape DOM
```

Graph-topology changes (UpsertNode / DeleteNode / AddEdge / RemoveEdge) flow through `project(state)`. **Selection / fit / current-zoom changes do not.** Instead, callers like `GraphNavigationService.handleNavigationToNode` do:

```ts
dispatchSelect([resolvedNodeId]);
node.select();  // [L2-seam-residual] cy-only: visual select — no store→cy selection projection exists
```

Two writes, one for the store, one for cytoscape. Convention keeps them aligned.

## The taxonomy question

State today is split unevenly across three buckets:

| Bucket | Examples | Lives where today |
|---|---|---|
| **Canonical graph data** | nodes, edges, parents, folder tree | `@vt/graph-state` (renderer mirror) — read from main daemon |
| **Persisted view state** | collapseSet, loadedRoots, layout positions | `@vt/graph-state` stores in renderer |
| **Contested middle** | selection, fit-to-node target, current zoom/pan | BOTH `@vt/graph-state` stores AND cytoscape (the residuals) |
| **Pure ephemera** | drag-in-progress, hover, animation tweens | cytoscape only (nobody contests this) |

The *contested middle* is the whole question.

## Goals / Non-Goals of this discussion

**Goals:**

- Decide whether selection / fit-target / current-zoom belong in `@vt/graph-state` or cytoscape.
- Produce a written rationale that resolves the `[L2-seam-residual]` labels (either "delete the cytoscape side and finish projection" or "delete the store side and accept ephemera").
- Identify the *concrete* trigger that would force one answer over the other (e.g. "agent X needs to read the user's selection").

**Non-Goals:**

- Implement either option.
- Re-open canonical-graph-data placement.
- Decide on multi-window / split-pane (mentioned only as a tiebreaker).

## Position A — Pure projection (`UI = project(state)`)

**Mechanism**: graph-state stores subscribe-trigger projection re-runs; cytoscape becomes a pure renderer; native cytoscape input handlers dispatch Commands.

**Arguments for:**

- One source of truth eliminates a class of bugs (store says X, cy shows Y) before they happen.
- Closes the cytoscape-ui-decoupling epic's logical end-state — parity becomes structural, not aspirational.
- Agent-driven UI features (e.g. "MCP tool that sets the user's selection to a node found by search") work with no new plumbing.
- Tests can drive UI selection without instantiating cytoscape — `dispatchSelect` then assert on the projected ElementSpec.

**Arguments against:**

- Adds ceremony to user-initiated UI gestures: a click is now `cy.on('tap') → intercept → dispatchSelect → store update → subscribe fires → project() → applyGraphDeltaToUI → cy.getElementById(id).select()` instead of cy's native one-step select.
- "Round-trip" only matters if anyone outside the UI cares about the result. If selection is purely UI-local, the round-trip is overhead with no consumer.
- Re-projecting on every selection change touches the entire ElementSpec even if only one node's `selected` flag changed. (Mitigated by reconciler diffing — but only mitigates; doesn't free.)

## Position B — Accept the split (UI ephemera stays in cytoscape)

**Mechanism**: declare selection / fit-target / current-zoom as UI-ephemeral; delete (or narrow) `selectionStore`; remove `[L2-seam-residual]` labels by re-classifying as "correct"; update `@vt/graph-state/decisions.md` to scope canonical State to graph topology + persisted view state only.

**Arguments for:**

- Honest naming. Selection in the UI and selection in `vt-graph view --select X` are *parallel* concepts (UI's selection is "what the user is looking at right now"; CLI's selection is "what this CLI invocation is filtering to") — pretending they're the same just because they share a name was the L2 mistake.
- Cytoscape is GPU-accelerated for these operations. `cy.fit()` runs an animated camera move; modelling that as state requires either a transition channel or imperative side-channel anyway.
- Per-cytoscape selection makes future multi-window trivial — each cytoscape instance has its own selection by construction, no per-window sessionId minting needed.
- Less code. The 11 residuals don't need to be migrated; they need to be relabelled.

**Arguments against:**

- If we ever want an MCP tool that drives the UI's cursor (e.g. for demos, agent-led tutorials, accessibility), we'd have to add new IPC plumbing rather than reusing the dispatch path.
- The L0/L1/L2 verification claims included selection in the parity matrix — backing it out requires updating those claims to "selection is intentionally NOT projected, parity does not apply". Slight bookkeeping cost.

## Position C — Hybrid (status quo, documented as deliberate)

**Mechanism**: relabel `[L2-seam-residual]` markers as `[L2-deliberate-dual-write]`; add per-residual rationale; commit a short note in `decisions.md`.

**Arguments for:**

- Zero risk. The system works; the parity test is green.
- Defers the decision until a forcing function appears.

**Arguments against:**

- "Documented dual-write" is a polite name for "the bug is deferred". A future contributor will see `dispatchSelect` immediately followed by `node.select()` and either (a) try to remove the imperative call (Option A by accident) or (b) try to remove the dispatch (Option B by accident). The dual-write is unstable equilibrium.
- The L2 residual catalogue grows over time as new features land in either bucket. Cost compounds.

## The forcing question

What concrete change in the world makes one option clearly correct?

| If… | Then… |
|---|---|
| An MCP tool ships that needs to *read* the user's current UI selection (e.g. "what is the user looking at?" for an agent assistant) | Option A — selection must flow through State so the MCP tool can subscribe to it. |
| An MCP tool ships that needs to *drive* the UI cursor (e.g. "select node X for the user" from an agent or remote) | Option A — same reason, write side. |
| Multi-window / split-pane ships and each pane has independent selection | Option B — per-cytoscape selection is the natural model; per-State-session selection requires per-window sessionId minting + IPC plumbing. |
| Headless tests need to assert on UI selection without spinning up cytoscape | Option A — but in practice tests already mount cytoscape and can read `cy.elements(':selected')`. Weak forcing function. |
| Agent-led UI demos (record/replay user gestures by replaying Commands) | Option A — Commands are the recording medium. |

Today **none of these have shipped**. The MCP tools that exist (`vt-graph live view`, `vt_get_live_state`, `vt_dispatch_live_command`) operate on the daemon's canonical state, not the renderer's selection. So no forcing function presses today.

## Recommended decision criteria

1. **Default to Option B** (UI ephemera stays in cytoscape) **unless** at least one Option-A forcing function is on a near-term roadmap (next 1-2 epics, not "someday").
2. If Option B is chosen, do the relabel + decision-doc update as a small follow-on. ~1 day of work.
3. If Option A is chosen later (because a forcing function does appear), the existing `selectionStore` + `dispatchSelect` infrastructure makes the migration cheap — wire subscriptions, intercept native input, delete the residuals. ~3-4 BF tickets.

## Open Questions

1. **Is there a concrete near-term feature that needs Option A's capabilities?** (Required input from the human.)
2. **Are `collapseSet` and `loadedRoots` definitely persistent / cross-client?** (If they're also actually viewer-local, the split goes deeper.)
3. **Layout positions specifically — do we want CLI consumers to read positions?** Today `vt-graph view` doesn't render positions, but a future visualisation tool might. If yes, layout stays in State even under Option B.
4. **What's the cost of the relabel pass under Option B?** Audit the 11 residuals — are they all genuinely "selection / fit / zoom-anchored", or are some legitimately incomplete migrations that should be finished regardless of A/B?

## Decision Owner

Defer to the human (Manu) for the forcing-question answer (Open Question 1). Once answered:

- Manu says "yes, near-term feature exists" → spawn `ui-pure-projection` openspec + 3-4 BF tickets.
- Manu says "no near-term feature" → spawn small `relabel-l2-residuals` change + decisions.md update.
- Manu says "unclear / defer" → archive this discussion as Option C (status quo) and revisit when a forcing function appears.
