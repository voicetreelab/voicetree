## Status

**DISCUSSION — not a committed change.** This openspec exists to surface an architectural question raised after `cytoscape-ui-decoupling` shipped. The output is a decision: pursue, defer, or reject. No code work is implied by merging this folder.

## Why

`cytoscape-ui-decoupling` extracted a pure data layer (`@vt/graph-state`: `State`, `Command`, `project(state) → ElementSpec`) and the renderer now calls `project(state)` on graph deltas. But selection / fit / collapse / layout still have **two writers** in the running UI: the dispatch path AND direct imperative cytoscape calls. The code openly admits this — see `webapp/src/shell/edge/UI-edge/graph/navigation/GraphNavigationService.ts:234-238` where `dispatchSelect([id])` is followed by `node.select()` with the inline comment *"no store→cy selection projection exists"*.

There are 11 such residuals catalogued at the end of L2 verification. Each is a place where the data layer says X and cytoscape independently shows Y. Today they're kept aligned by convention; the parity test passes only because the convention is followed manually.

The question is whether to close this gap (make `UI = project(state)` the single render path) or to formally accept the split (selection / fit / etc. are UI-local ephemera, not part of canonical State).

## What is being discussed

Three options, with the open question deciding between them:

**Option A — Pure projection.** Wire subscriptions on `selectionStore` / `collapseSet` / `layoutStore` that trigger `refreshProjectionFromStores()`. Replace every imperative `node.select()` / `cy.fit()` / `node.unselect()` with a Command dispatch. Intercept native cytoscape input (`cy.on('tap', …)`) and turn it into commands too. The 11 residuals go to 0.

**Option B — Accept the split.** Formally declare selection / fit / current-zoom / hover / drag-in-progress as **UI-ephemeral state** that lives in cytoscape and is *not* mirrored into `@vt/graph-state`. Keep collapseSet / loaded-roots / persisted layout in graph-state because those are user-meaningful and may need cross-client coherence. Delete the existing `selectionStore` (or scope it to "last persisted selection" if a use case emerges). The 11 residuals get re-classified from "debt" to "correct".

**Option C — Hybrid (status quo, with the residuals documented as deliberate).** Keep the current architecture: graph-state owns selection/layout in *theory*, cytoscape mirrors it in *practice*. Add per-residual rationale so future readers don't try to "clean them up". This is the least work but bakes in the divergence risk.

## Key Open Question

**Does any non-UI consumer (CLI, MCP agent, headless test) need to read or drive the UI's selection / fit-target / current-zoom?**

- **YES** → Option A is justified; the data layer is the *integration point* and selection has to flow through it.
- **NO** → Option B is the cleaner architecture; selection is viewer-local and round-tripping through `State` adds ceremony for no behavioural gain. The CLI's `vt-graph view --select X` is a *parallel* selection concept (the CLI's view, not the UI's view), not a shared cursor.

The user's prior framing (`maybe it's best to actually keep node selection, fit, etc. just only in the cytoscape renderer layer, and only have it as ui ephemeral state`) leans toward **Option B**. This proposal does NOT pre-decide; it asks the open question explicitly so we can answer it before any implementation work is queued.

## Why this matters now

- The decision affects whether the 11 residuals are *bugs* or *correct*. Today they're labelled `[L2-seam-residual]` — ambiguous.
- It affects whether agent-driven UI demos (e.g. an MCP tool that sets the user's selection or fits to a node) are possible structurally or require new IPC plumbing.
- It affects how multi-window / split-pane future work is modelled — if selection is per-cytoscape, multi-window is trivial; if selection is per-State-session, multi-window must mint per-window sessions.

## Out of Scope

- Any implementation work. This change produces a decision document only.
- Re-litigating `cytoscape-ui-decoupling`. Graph topology + persisted view state living in `@vt/graph-state` is settled.
- The `UI ephemera` taxonomy (drag-in-progress, hover, animations) — those are uncontested cytoscape-only.

## Impact

- **Modified**: nothing. This proposal is a discussion artifact.
- **Follow-on if Option A wins**: a real openspec (`ui-pure-projection`) with implementation tasks, ~3 BF tickets.
- **Follow-on if Option B wins**: a one-shot change deleting `selectionStore` (or narrowing its scope), removing the `[L2-seam-residual]` labels, and updating `decisions.md` in `@vt/graph-state` to formally exclude UI-ephemeral state from canonical State.
- **Follow-on if Option C wins**: documentation pass on `decisions.md` to record the status quo as deliberate.
