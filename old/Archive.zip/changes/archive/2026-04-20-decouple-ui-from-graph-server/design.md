## Context

Discovery report `voicetree-19-4/leo-vt-cli-vs-ui-state-parity-discovery.md` mapped the current architecture:

- Canonical state lives as in-memory module singletons in two packages already extracted from the UI: `@vt/graph-model` (graph + vault read/write paths + filesystem watcher handle) and `@vt/graph-state` (collapseSet + selection + layout).
- Those singletons are instantiated inside the Electron main process at boot. There is no other process that owns them.
- Two transports leave main: **IPC** (`electronAPI.main.*`) which the UI uses for both reads and writes, and **HTTP MCP** at `:3001/mcp` which the CLI uses for reads only (`vt_get_live_state`, `create_graph`, agent control). The MCP server has no mutation tools for vault paths or view state.
- UI projection is built by `webapp/src/shell/edge/main/state/buildLiveStateSnapshot.ts:73`. UI consumes via IPC `getLiveStateSnapshot`; CLI consumes the same projection via MCP `vt_get_live_state`.

Constraints and prior decisions to respect:
- Filesystem is the source of truth — markdown files are canonical, no separate database. The "graph DB" is a parser+index over a folder, not a new persistence layer.
- `~/brain/feedback_mcp_port_3002.md`: port 3002 is reserved for orchestration MCP; tests must not bind it. The graph-db daemon must NOT use 3002.
- In-flight Wave B (`unified-folder-file-nodes`, agents Kai/Lou) is editing `packages/graph-state/src/project.ts` and the projection layer. This change must sequence around it.
- `BF-104-decouple-webapp` and `BF-058-vt-cli-default-interface` in `~/brain/working-memory/kanban.md` already flag this direction; this change formalises it.

## Goals / Non-Goals

**Goals:**
- A single long-running process (`vt-graphd`) owns canonical vault + graph state for one vault. UI and CLI are clients.
- `vt-graphd` boots without Electron. CLI commands (`vt vault add-read-path`, `vt view collapse <id>`, etc.) work whether or not the desktop app is open.
- View state (collapseSet, selection, layout) is per-session. Two clients (UI session + a CLI session, or two UIs) can hold different views simultaneously without stomping each other.
- One backend function per operation. UI and CLI route through the same daemon endpoint, which calls the same `@vt/graph-model` / `@vt/graph-state` function. No duplication.
- Existing UI behaviour is preserved end-to-end (no user-visible regression).

**Non-Goals:**
- New persistence layer (no SQLite, no embedded KV store). Filesystem stays the source of truth.
- Multi-vault concurrent serving from one daemon. One vault per daemon process; multiple vaults run multiple daemons on different ports.
- Network-exposed daemon. `vt-graphd` binds to `127.0.0.1` only. Auth deferred until we have a remote-access use case.
- Splitting `@vt/graph-model` into a separate "DB-only" package right now. The package is already pure enough to serve as both the parser and the daemon's in-memory backing.
- Rewriting MCP server semantics. The existing MCP server can either be folded into `vt-graphd` or kept as a sibling that proxies to it; design pick is below.

## Decisions

1. **One daemon binary, `vt-graphd`, in a new `packages/graph-db-server/` package.**
   Rationale: keeps the daemon's deps (HTTP server, watcher, session manager) out of `@vt/graph-model` (which we want to stay pure-ish so it can run in tests, in webworkers, in CI). The daemon depends on graph-model + graph-state; graph-model + graph-state never depend on the daemon.
   Alternatives considered: bake into `@vt/graph-model` (rejected — pollutes the pure layer); keep inside `webapp/src/shell/edge/main/` (rejected — that's the thing we're trying to extract from).

2. **Transport: HTTP/JSON over `127.0.0.1:<dynamic-port>`. No WebSocket in v1.**
   Rationale: HTTP gives us trivial CLI integration (curl, fetch), debuggability, and matches the existing MCP transport mental model. Dynamic port avoids collisions when multiple vaults run; port written to a discovery file at `<vault>/.voicetree/graphd.port`. WebSocket is deferred until we need server-push for live updates (which we do — see #5).
   Alternatives considered: Unix domain socket (rejected — Windows portability later); gRPC (rejected — overkill for one-machine localhost).

3. **Live updates: long-poll for v1, upgrade to SSE in v2.**
   Rationale: v1 ships fastest by reusing today's polling pattern (UI's `getLiveStateSnapshot()` already polls on each delta IPC). SSE is the right long-term answer (server pushes deltas; sessions subscribe). Not WebSocket — SSE is one-directional and matches "server pushes deltas, client posts mutations" perfectly.
   Alternatives considered: chokidar-events-as-IPC (rejected — couples consumers to filesystem-event shape); WebSocket (rejected for v1; possibly later if we need bidirectional).

4. **Sessions are server-side objects keyed by `sessionId` (UUIDv4), created on first request.**
   Rationale: keeping sessions on the server lets us share view state across multiple clients of the same session (e.g. two CLI invocations in the same workflow can pin the same sessionId and see the same collapseSet). UI mints a sessionId at boot, persists it for the lifetime of the window, sends it on every request. CLI defaults to a fresh sessionId per invocation but accepts `--session <id>` for pinning.
   Alternatives considered: client-side session state (rejected — defeats the "view state is shareable" benefit and forces every CLI call to upload its full session); cookie auth (rejected — overkill for localhost).

5. **`vt-graphd` is auto-launched by whichever client connects first.**
   Rationale: UX. User runs `vt vault add-read-path /foo` cold and it Just Works — the CLI launches the daemon, waits for ready, runs the command. Electron also launches the daemon at boot if not already running. Discovery via `<vault>/.voicetree/graphd.port` + a PID-liveness check; if dead, relaunch. Single instance per vault is enforced by an exclusive file lock on `<vault>/.voicetree/graphd.lock`.
   Alternatives considered: require explicit `vt graphd start` (rejected — too much friction); systemd-style service (rejected — premature for a desktop app).

6. **Electron main keeps its IPC surface; handlers become daemon-client proxies.**
   Rationale: minimum disruption to renderer code. Renderer continues to call `window.electronAPI.main.setWritePath(p)`. Main's handler now does `daemonClient.setWritePath(sessionId, p)`. This lets us land the daemon without simultaneously rewriting the renderer.
   Alternatives considered: renderer talks directly to daemon HTTP (rejected for v1 — bigger blast radius; deferred to a later "thin Electron" change).

7. **Sequencing: land AFTER Wave B (`unified-folder-file-nodes`) B5.**
   Rationale: Wave B is actively rewriting `project.ts` and the projection contract. Touching the same files concurrently would force a non-trivial merge. Wave B is small phases (B2 in flight, B3–B5 sized similarly) — we can wait. We start design + specs + tasks now; impl waits.
   Alternatives considered: feature-flag both (rejected — flags are debt; the work is sequential anyway).

8. **MCP server stays where it is for v1, then migrates to the daemon in v2.**
   Rationale: the MCP server has agent-control semantics (spawn/list/wait/close) that involve PTYs and Electron lifecycle. Cleanly separating "graph endpoints" from "agent endpoints" is a separate refactor. v1: `vt-graphd` exposes graph + view endpoints; the existing MCP server keeps agent endpoints AND proxies its `vt_get_live_state` tool to `vt-graphd`. v2 (out of scope here): merge or split cleanly.
   Alternatives considered: merge in v1 (rejected — scope blow-up); deprecate MCP entirely (rejected — agents depend on it).

9. **Persistence model: nothing the filesystem doesn't already persist.**
   Rationale: vault paths are stored where they live today (`~/Library/Application Support/Voicetree/...` JSON). Per-session view state is RAM-only by design (closing the window resets your view). If we ever want persistent collapse-state-per-vault, that's `.vt-session/collapse.json` (already mooted as Wave C in `unified-folder-file-nodes/design.md`) — separate change.
   Alternatives considered: SQLite for sessions (rejected — overkill, adds a dep); LMDB (rejected — same).

10. **CLI client: thin TypeScript wrapper in `packages/graph-db-client/`.**
    Rationale: both `voicetree-cli` and Electron main need a typed client; sharing it avoids two parallel API drift problems. Generated from a small contract module (Zod schemas) so request/response types are end-to-end checked.
    Alternatives considered: hand-rolled fetch in each consumer (rejected — drift); OpenAPI codegen (rejected — overkill for ~15 endpoints).

## Risks / Trade-offs

- **Auto-launching daemon deadlocks on missing vault.** → Daemon refuses to launch without a `--vault <path>` flag; CLI passes the vault from cwd or `--vault`; Electron passes the user-selected vault. Failures are explicit errors, not hangs.
- **Two writers (UI + CLI) racing on the same vault state.** → Daemon serializes mutations on a single in-process queue. Filesystem watcher sees writes from both clients identically. Last-write-wins on disk is the existing semantic; this change does not strengthen or weaken it.
- **Watcher mounted twice (daemon + Electron leftover).** → As part of this change, Electron stops mounting its own chokidar watcher; the daemon owns it exclusively. Verified by lsof / process inspection during impl.
- **Dynamic-port discovery race on first launch.** → Use atomic file write (write to tmp + rename) for `graphd.port`; clients retry with exponential backoff up to 5s. Liveness via small `/health` ping.
- **Per-session view state diverges from "what user expects to persist."** → Acceptable for v1; users today already lose collapse state on app restart (no persistence). If this becomes painful, layer `.vt-session/collapse.json` per Wave C of unified-folder-file-nodes.
- **`@vt/graph-model` callers outside the daemon (tests, scripts) bypass the new boundary.** → Add an ESLint rule banning direct imports of the mutation functions from outside `packages/graph-db-server/`. Test fixtures get explicit allow-list. Migration of existing direct callers happens as part of this change.
- **Test surface area explodes (now we have an HTTP boundary to test).** → Mitigation: keep the daemon thin (HTTP layer is a Hono/Express adapter; logic is in `@vt/graph-model`/`@vt/graph-state` which already has tests). Add one e2e per endpoint group + a single in-process daemon harness for client tests.
- **Sequencing risk: Wave B drags out and blocks us.** → Acceptable. Phases 1–3 of this change (proposal, design, prototype daemon in isolation) can run in parallel with Wave B. Only Phase 4 (wire Electron main as proxy) waits.

## Migration Plan

1. **Phase 0 — openspec change (this doc + specs + tasks).** No code. Done when proposal/design/specs/tasks land in `openspec/changes/decouple-ui-from-graph-server/`.
2. **Phase 1 — `packages/graph-db-server/` skeleton + contract.** New package. Hono HTTP server, Zod contract module, `/health`, in-memory state seed. No watcher, no real endpoints. Unit tests on the contract module.
3. **Phase 2 — Endpoints group A (vault control).** `GET /vault`, `POST /vault/read-paths`, `DELETE /vault/read-paths/:path`, `PUT /vault/write-path`. Wires through to `@vt/graph-model` mutation functions. Daemon-level integration tests.
4. **Phase 3 — Endpoints group B (graph + projection).** `GET /graph`, `GET /sessions/:id/state`. Mounts chokidar watcher. Re-uses `buildLiveStateSnapshot` logic.
5. **Phase 4 — Endpoints group C (view-session).** `POST /sessions`, `POST /sessions/:id/collapse/:folderId`, `DELETE /sessions/:id/collapse/:folderId`, `POST /sessions/:id/selection`, `PUT /sessions/:id/layout`. Session manager.
6. **Phase 5 — `packages/graph-db-client/`.** Typed client. Used in Phase 6 + Phase 7.
7. **Phase 6 — CLI parity subcommands.** `vt vault add-read-path`, `remove-read-path`, `set-write-path`, `vt view collapse <id>`, `expand <id>`. Auto-launch daemon if not running. CLI-level e2e tests.
8. **Phase 7 — Electron main as proxy.** Replace IPC handler bodies with daemon-client calls. Remove the now-orphaned chokidar mount in main. Manual smoke + existing Playwright suite.
9. **Phase 8 — Cleanup + lint rule.** ESLint rule banning direct mutation-function imports from outside the daemon. Remove dead code in `@vt/graph-model` / `@vt/graph-state` if any.

Rollback: each phase is a separate commit. Phases 1–6 are additive (no behaviour change for UI). Phase 7 is the only one that swaps a behaviour path; it can be reverted by a single commit revert and the daemon stays as a no-op service.

## Open Questions

- Should `vt-graphd` write daemon logs anywhere durable for debugging? **Proposal:** rotating log file at `<vault>/.voicetree/graphd.log`, off by default, enable with `--log-level debug`. **Confirm during Phase 1.**
- How does the daemon discover the vault when launched standalone (no Electron, no cwd-in-vault)? **Proposal:** require `--vault <path>` flag; CLI defaults to nearest ancestor containing `.voicetree/`; Electron passes the user-selected vault. **Confirm during Phase 1.**
- Should sessionId be embedded in the URL path (`/sessions/:id/state`) or a header (`X-VT-Session`)? **Proposal:** URL path for view-state endpoints (it's part of the resource); header for cross-cutting endpoints (e.g. an audit trail). **Confirm during Phase 4.**
- Does the MCP server's `vt_get_live_state` tool implementation move into the daemon, or does MCP proxy to the daemon? **Locked:** MCP proxies for v1 (per Decision 8). Re-open after v1 ships if the proxy hop costs us.
- Do we need a `vt graphd status` / `vt graphd stop` CLI for ops? **Deferred.** Not strictly needed for v1; add when first user asks.
