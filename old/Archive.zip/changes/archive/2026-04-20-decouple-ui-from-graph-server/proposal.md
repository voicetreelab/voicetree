## Why

Today the canonical graph state (vault read/write paths, graph nodes, collapse/expand, selection, layout) lives as in-memory module-singletons inside the Electron main process. Mutation paths are IPC-only, so the UI can change vault state but the CLI cannot — confirmed by `voicetree-19-4/leo-vt-cli-vs-ui-state-parity-discovery.md`. CLI/agents cannot operate against a vault when the app isn't running, and the UI is structurally coupled to "the server." We want a clean three-layer model: (1) **graph DB** = pure folder↔markdown-graph parser, (2) **CRUD server** = long-running headless process that owns canonical state and exposes HTTP for transactions, (3) **view server** = ephemeral per-client-session projection (collapseSet, selection, layout) so multiple clients (UI, CLI, agents) can each have their own view onto the same graph.

## What Changes

- **New `vt-graphd` daemon** — long-running headless process. Owns the canonical state currently held by `@vt/graph-model` and `@vt/graph-state` singletons. Boots without Electron. Mounts the chokidar watcher. Single instance per vault, port-discoverable.
- **HTTP API on `vt-graphd`** — replaces in-process function calls as the canonical mutation surface. Endpoints for vault read/write paths, graph CRUD, and live-state projection. Both UI (today's IPC handlers) and CLI go through this.
- **Per-session view state** — collapseSet, selection, layout, and any other ephemeral per-viewer state moves out of the global `@vt/graph-state` singletons into a `Session` object identified by `sessionId`. View endpoints take a `sessionId`. The UI gets a sessionId at boot; the CLI mints one per invocation (or pins one for a given workflow).
- **Electron main becomes a thin adapter** — boots `vt-graphd` as an embedded child process (or attaches to a running one), keeps IPC handlers as a transport adapter that proxies to `vt-graphd`. No business logic in main.
- **CLI parity subcommands** — `voicetree-cli vault add-read-path`, `vault remove-read-path`, `vault set-write-path`, `view collapse <folderId>`, `view expand <folderId>`, all hitting `vt-graphd` HTTP. CLI works whether or not Electron is running.
- **BREAKING for internal contributors only**: callers that imported `@vt/graph-model` mutation functions directly (e.g. `setWritePath`, `dispatchCollapse`) must go through the daemon client. Internal package code is updated in the same change; no public API surface today.

### Capabilities

#### New Capabilities
- `graph-db-server`: long-running headless daemon (`vt-graphd`) that owns canonical vault + graph state, exposes HTTP CRUD endpoints, mounts the filesystem watcher, persists nothing the filesystem doesn't already persist. Replaces in-process `@vt/graph-model` and `@vt/graph-state` singletons as the source of truth.
- `view-session`: per-client-session ephemeral view state (collapseSet, selection, layout) keyed by sessionId. Multiple clients can hold different views on the same graph. Replaces today's global singletons for view state.
- `cli-vault-control`: CLI parity for the file-tree/vault operations currently UI-only — read path add/remove, write folder set, collapse/expand. All routed through `vt-graphd` HTTP, sharing the same backend functions as the UI.

### Modified Capabilities

None — this is a new architectural layer; existing capability specs (folder-as-node, folder-collapse) keep their requirements but their implementation moves behind the daemon. Implementation moves are not capability changes.

## Impact

- **New process**: `vt-graphd` binary (likely under `packages/graph-db-server/` with a `bin/` entry).
- **New package** (proposed): `packages/graph-db-server/` housing the HTTP server, session manager, and watcher mount. Re-uses `@vt/graph-model` (parser/types) and `@vt/graph-state` (projection logic) as pure libraries.
- **New package** (proposed): `packages/graph-db-client/` — typed HTTP client used by both Electron main and the CLI, so neither hand-rolls fetch calls.
- **Modified**: `webapp/src/shell/edge/main/api.ts` — IPC handlers re-implemented as proxies to the daemon client.
- **Modified**: `webapp/src/shell/edge/main/electron/main.ts` — boot/attach `vt-graphd` as a child process; pass its port to the renderer.
- **Modified**: `webapp/src/shell/edge/UI-edge/state/FolderTreeStore.ts`, `rendererStateMirror.ts`, layout/collapse stores — read/write through the daemon (or via main as today, but main's handlers now proxy).
- **Modified**: `webapp/src/shell/edge/main/cli/voicetree-cli.ts` + `commands/` — new vault and view subcommands.
- **Modified**: `packages/graph-model/src/state/*` and `packages/graph-state/src/state/*` singletons — either deleted or repurposed as in-memory backing for the daemon process only. Direct imports from outside the daemon become illegal (linted).
- **Removed**: nothing user-visible; this is a refactor + new daemon.
- **Coordination**: in-flight Wave B (`unified-folder-file-nodes`, Kai/Lou) is touching `project.ts` and the projection layer. This change should land AFTER Wave B B5 to avoid merge churn, OR be sequenced behind a feature flag. Decision deferred to design.md.
