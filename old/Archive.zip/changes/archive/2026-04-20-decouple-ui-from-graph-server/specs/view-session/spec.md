## ADDED Requirements

### Requirement: Sessions are server-side and identified by sessionId
The daemon SHALL maintain per-session ephemeral view state, keyed by a `sessionId` (UUIDv4 string). View state SHALL include at minimum: `collapseSet` (set of folder ids currently collapsed), `selection` (set of node ids currently selected), and `layout` (per-node positions and viewport pan/zoom).

#### Scenario: Session created on first request
- **WHEN** a client issues `POST /sessions` with no body
- **THEN** the daemon creates a new session, returns `{ sessionId }`, and initializes its view state to empty defaults

#### Scenario: Session view state survives across requests
- **GIVEN** a sessionId returned by `POST /sessions`
- **WHEN** the client mutates the session's collapseSet
- **THEN** subsequent reads of `GET /sessions/:id/state` reflect the mutation

### Requirement: Sessions are isolated
View state mutations on one session SHALL NOT affect any other session. Two clients holding different sessionIds SHALL see independent collapseSet, selection, and layout.

#### Scenario: Independent collapse state
- **GIVEN** sessions A and B both started against the same vault
- **WHEN** session A collapses folder X
- **THEN** session B's view shows folder X expanded
- **AND** session B's collapseSet does not contain X

### Requirement: Sessions can be shared by sessionId pinning
A client SHALL be able to opt into another session's view by passing the same sessionId. Two clients sharing a sessionId SHALL see and contribute to the same view state.

#### Scenario: CLI joins UI session
- **GIVEN** the UI is running with sessionId "abc"
- **WHEN** a CLI invocation runs `vt --session abc view collapse <folderId>`
- **THEN** the UI's projection updates to show that folder collapsed without any UI interaction

### Requirement: Collapse-set mutation endpoints
The daemon SHALL expose `POST /sessions/:sessionId/collapse/:folderId` to add a folder to the session's collapseSet, and `DELETE /sessions/:sessionId/collapse/:folderId` to remove it. Both SHALL invoke the same `dispatchCollapse` / `dispatchExpand` semantics that today's UI invokes (currently from `@vt/graph-state/collapseSetStore`).

#### Scenario: Collapse a folder
- **WHEN** a client POSTs `/sessions/abc/collapse/<folderId>`
- **THEN** the session's collapseSet contains that folderId
- **AND** the next `GET /sessions/abc/state` projection marks that folder's NodeElement.kind as `'folder-collapsed'`

#### Scenario: Expand a folder
- **WHEN** a client DELETEs `/sessions/abc/collapse/<folderId>`
- **THEN** the session's collapseSet no longer contains that folderId
- **AND** the next projection marks the folder as `'folder'` (compound parent)

### Requirement: Selection mutation endpoint
The daemon SHALL expose `POST /sessions/:sessionId/selection` accepting `{ nodeIds: string[], mode: 'replace' | 'add' | 'remove' }`. The mutation SHALL update the session's selection set accordingly.

#### Scenario: Replace selection
- **WHEN** a client POSTs `{ nodeIds: ["a", "b"], mode: "replace" }` to `/sessions/abc/selection`
- **THEN** the session's selection set equals `{ "a", "b" }` regardless of prior contents

#### Scenario: Add to selection
- **GIVEN** session selection is `{ "a" }`
- **WHEN** a client POSTs `{ nodeIds: ["b"], mode: "add" }`
- **THEN** the session's selection set is `{ "a", "b" }`

### Requirement: Layout mutation endpoint
The daemon SHALL expose `PUT /sessions/:sessionId/layout` accepting `{ positions: Record<nodeId, { x, y }>, pan?: { x, y }, zoom?: number }`. The mutation SHALL replace the named fields and leave un-named fields untouched.

#### Scenario: Update node positions only
- **WHEN** a client PUTs `{ positions: { "a": { x: 10, y: 20 } } }`
- **THEN** the session's layout positions for "a" become `{ x: 10, y: 20 }`
- **AND** the session's pan and zoom are unchanged

### Requirement: View state is RAM-only and per-session
View state SHALL NOT be persisted to disk by this change. Daemon restart SHALL drop all session state. New sessions SHALL start with empty defaults.

#### Scenario: Daemon restart wipes sessions
- **GIVEN** a session "abc" with non-empty collapseSet
- **WHEN** the daemon is restarted
- **THEN** `GET /sessions/abc/state` returns 404 OR returns empty defaults (the session is treated as new)

### Requirement: Session lifecycle
Sessions SHALL be created lazily on first reference and SHALL be eligible for cleanup after a configurable idle timeout (default: 24 hours of no requests). Closing a session SHALL be possible explicitly via `DELETE /sessions/:sessionId`.

#### Scenario: Explicit close
- **WHEN** a client DELETEs `/sessions/abc`
- **THEN** the session is removed from the daemon's state
- **AND** subsequent requests against `/sessions/abc/...` return 404

#### Scenario: Idle timeout
- **GIVEN** a session that has received no requests for the configured idle timeout
- **WHEN** the daemon's cleanup tick runs
- **THEN** the session is removed and its memory is reclaimed
