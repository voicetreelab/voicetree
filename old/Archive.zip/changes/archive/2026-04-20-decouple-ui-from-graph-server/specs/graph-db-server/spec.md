## ADDED Requirements

### Requirement: Daemon owns canonical vault state
The system SHALL provide a long-running headless process named `vt-graphd` that owns the canonical vault state for one vault. Vault state means: the set of read paths, the write path, the in-memory graph parsed from those paths, and the active filesystem watcher. No other process SHALL hold mutable copies of this state.

#### Scenario: Single source of truth for write path
- **WHEN** a client mutates the write path via the daemon HTTP API
- **THEN** subsequent reads from any other client return the new write path
- **AND** the change is reflected in the next live-state projection emitted to all subscribed sessions

#### Scenario: No duplicate watcher
- **WHEN** `vt-graphd` is the sole owner of the vault watcher
- **THEN** Electron main does not mount its own chokidar instance
- **AND** filesystem events for files inside read paths are observed exactly once across the whole system

### Requirement: Daemon runs without Electron
The daemon SHALL boot, serve requests, and shut down independently of the Electron desktop application. CLI invocations SHALL succeed when Electron is not running.

#### Scenario: Cold-start CLI
- **WHEN** Electron is not running and the user runs `vt vault add-read-path /some/folder`
- **THEN** the CLI auto-launches `vt-graphd` for the current vault
- **AND** the command completes successfully and persists the new read path

#### Scenario: Daemon outlives client
- **WHEN** a CLI command completes
- **THEN** the daemon continues running and serving subsequent requests without re-initialisation

### Requirement: Single instance per vault
At most one `vt-graphd` process SHALL serve a given vault at any time. Concurrent launch attempts SHALL coalesce to a single running daemon.

#### Scenario: Concurrent launch race
- **WHEN** two clients attempt to launch the daemon for the same vault simultaneously
- **THEN** exactly one daemon process becomes the owner
- **AND** the other launch attempt detects the running daemon and connects to it

#### Scenario: Stale lock recovery
- **WHEN** a previous daemon crashed and left a lock file behind
- **AND** no live process holds the lock
- **THEN** a new daemon launch claims the lock and starts cleanly

### Requirement: HTTP transport on localhost only
The daemon SHALL expose its API over HTTP on `127.0.0.1` only. The daemon SHALL NOT bind to any non-loopback interface in v1. The port SHALL be dynamic and discoverable via a port file at `<vault>/.voicetree/graphd.port`.

#### Scenario: External access denied
- **WHEN** a request arrives from a non-loopback address
- **THEN** the daemon refuses the connection
- **AND** logs the rejected source address

#### Scenario: Port discovery
- **WHEN** a client wants to connect to the daemon
- **THEN** it reads the port from `<vault>/.voicetree/graphd.port`
- **AND** verifies liveness by hitting `GET /health` before issuing real requests

### Requirement: Health endpoint
The daemon SHALL expose `GET /health` that returns 200 with a JSON body containing daemon version, vault path, uptime, and active session count. This endpoint SHALL NOT require a session.

#### Scenario: Liveness probe
- **WHEN** any client issues `GET /health`
- **THEN** the response is 200
- **AND** the body includes `{ version, vault, uptimeSeconds, sessionCount }`

### Requirement: Vault-control endpoints
The daemon SHALL expose endpoints for reading and mutating vault paths: `GET /vault`, `POST /vault/read-paths`, `DELETE /vault/read-paths/:encodedPath`, `PUT /vault/write-path`. These endpoints SHALL invoke the same `@vt/graph-model` mutation functions that today's Electron IPC handlers invoke.

#### Scenario: Add read path via HTTP
- **WHEN** a client POSTs `{ "path": "/foo/bar" }` to `/vault/read-paths`
- **THEN** the daemon calls `addReadPath('/foo/bar')` from `@vt/graph-model`
- **AND** the response includes the updated full vault descriptor
- **AND** subsequent `GET /vault` includes `/foo/bar` in `readPaths`

#### Scenario: Set write path via HTTP
- **WHEN** a client PUTs `{ "path": "/foo/baz" }` to `/vault/write-path`
- **THEN** the daemon calls `setWritePath('/foo/baz')` from `@vt/graph-model`
- **AND** the response is 200 with the updated vault descriptor

### Requirement: Graph endpoint
The daemon SHALL expose `GET /graph` returning the in-memory graph (nodes + edges) as JSON. The shape SHALL match the existing `@vt/graph-model` `Graph` type.

#### Scenario: Read full graph
- **WHEN** a client requests `GET /graph`
- **THEN** the response body equals `getGraph()` from `@vt/graph-model` serialised as JSON

### Requirement: Session-projection endpoint
The daemon SHALL expose `GET /sessions/:sessionId/state` returning the live-state projection for that session. The projection SHALL be assembled the same way `buildLiveStateSnapshot()` assembles it today: graph + vault + filesystem-walked folder tree + the session's collapseSet, selection, and layout.

#### Scenario: Session view differs from another session
- **GIVEN** two sessions A and B
- **WHEN** session A toggles a folder collapsed
- **THEN** `GET /sessions/A/state` shows the folder as collapsed
- **AND** `GET /sessions/B/state` shows the folder as expanded

### Requirement: Filesystem watcher emits delta events
The daemon SHALL mount a chokidar watcher over the union of read paths. Watcher events SHALL update the in-memory graph and trigger a re-projection for all active sessions.

#### Scenario: External file create
- **WHEN** a markdown file is created externally inside a read path
- **THEN** the daemon's graph reflects the new node
- **AND** the next state projection for any session includes the new node

#### Scenario: Read path added at runtime
- **WHEN** a client adds a read path
- **THEN** the watcher is updated to include the new path
- **AND** files under that path appear in the graph without restarting the daemon

### Requirement: No new persistence layer
The daemon SHALL NOT introduce a database or other persistent store beyond what already exists. Vault path persistence SHALL continue to use the existing application-support JSON. Per-session view state SHALL be RAM-only.

#### Scenario: Daemon restart drops view state
- **WHEN** the daemon is restarted
- **THEN** all per-session view state (collapseSet, selection, layout) is empty for new sessions
- **AND** vault paths persisted via the existing mechanism are restored

### Requirement: Daemon lifecycle endpoints
The daemon SHALL expose `POST /shutdown` for graceful shutdown. It SHALL NOT expose remote start (start is the launcher's responsibility).

#### Scenario: Graceful shutdown
- **WHEN** a client POSTs `/shutdown`
- **THEN** the daemon flushes pending state, closes the watcher, releases the lock file, deletes the port file, and exits with code 0
