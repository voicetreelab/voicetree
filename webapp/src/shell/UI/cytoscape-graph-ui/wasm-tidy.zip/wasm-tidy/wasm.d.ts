/* tslint:disable */
/* eslint-disable */
export function start(): void;
export enum WasmLayoutType {
  Basic = 0,
  Tidy = 1,
  LayeredTidy = 2,
}
export class Tidy {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  static null_id(): number;
  static with_basic_layout(parent_child_margin: number, peer_margin: number): Tidy;
  static with_tidy_layout(parent_child_margin: number, peer_margin: number): Tidy;
  static with_layered_tidy(parent_child_margin: number, peer_margin: number): Tidy;
  change_layout(layout_type: WasmLayoutType): void;
  remove_node(id: number): void;
  update_node_size(id: number, width: number, height: number): void;
  set_parent(id: number, parent_id: number): void;
  is_empty(): boolean;
  add_node(id: number, width: number, height: number, parent_id: number): void;
  data(id: Uint32Array, width: Float64Array, height: Float64Array, parent_id: Uint32Array): void;
  layout(): void;
  partial_layout(changed_ids: Uint32Array): void;
  get_pos(): Float64Array;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_tidy_free: (a: number, b: number) => void;
  readonly tidy_null_id: () => number;
  readonly tidy_with_basic_layout: (a: number, b: number) => number;
  readonly tidy_with_tidy_layout: (a: number, b: number) => number;
  readonly tidy_with_layered_tidy: (a: number, b: number) => number;
  readonly tidy_change_layout: (a: number, b: number) => void;
  readonly tidy_remove_node: (a: number, b: number) => void;
  readonly tidy_update_node_size: (a: number, b: number, c: number, d: number) => void;
  readonly tidy_set_parent: (a: number, b: number, c: number) => void;
  readonly tidy_is_empty: (a: number) => number;
  readonly tidy_add_node: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly tidy_data: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => void;
  readonly tidy_layout: (a: number) => void;
  readonly tidy_partial_layout: (a: number, b: number, c: number) => void;
  readonly tidy_get_pos: (a: number) => [number, number];
  readonly start: () => void;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_export_3: WebAssembly.Table;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
