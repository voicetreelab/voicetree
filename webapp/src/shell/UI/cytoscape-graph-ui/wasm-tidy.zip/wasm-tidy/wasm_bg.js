let wasm;
export function __wbg_set_wasm(val) {
    wasm = val;
}


function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_export_2.set(idx, obj);
    return idx;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

let cachedUint8ArrayMemory0 = null;

function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedUint32ArrayMemory0 = null;

function getUint32ArrayMemory0() {
    if (cachedUint32ArrayMemory0 === null || cachedUint32ArrayMemory0.byteLength === 0) {
        cachedUint32ArrayMemory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32ArrayMemory0;
}

let WASM_VECTOR_LEN = 0;

function passArray32ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 4, 4) >>> 0;
    getUint32ArrayMemory0().set(arg, ptr / 4);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

let cachedFloat64ArrayMemory0 = null;

function getFloat64ArrayMemory0() {
    if (cachedFloat64ArrayMemory0 === null || cachedFloat64ArrayMemory0.byteLength === 0) {
        cachedFloat64ArrayMemory0 = new Float64Array(wasm.memory.buffer);
    }
    return cachedFloat64ArrayMemory0;
}

function passArrayF64ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 8, 8) >>> 0;
    getFloat64ArrayMemory0().set(arg, ptr / 8);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function getArrayF64FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getFloat64ArrayMemory0().subarray(ptr / 8, ptr / 8 + len);
}
/**
 * @enum {0 | 1 | 2}
 */
export const WasmLayoutType = Object.freeze({
    Basic: 0, "0": "Basic",
    Tidy: 1, "1": "Tidy",
    LayeredTidy: 2, "2": "LayeredTidy",
});

const TidyFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_tidy_free(ptr >>> 0, 1));

export class Tidy {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(Tidy.prototype);
        obj.__wbg_ptr = ptr;
        TidyFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TidyFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_tidy_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    static null_id() {
        const ret = wasm.tidy_null_id();
        return ret >>> 0;
    }
    /**
     * @param {number} parent_child_margin
     * @param {number} peer_margin
     * @returns {Tidy}
     */
    static with_basic_layout(parent_child_margin, peer_margin) {
        const ret = wasm.tidy_with_basic_layout(parent_child_margin, peer_margin);
        return Tidy.__wrap(ret);
    }
    /**
     * @param {number} parent_child_margin
     * @param {number} peer_margin
     * @returns {Tidy}
     */
    static with_tidy_layout(parent_child_margin, peer_margin) {
        const ret = wasm.tidy_with_tidy_layout(parent_child_margin, peer_margin);
        return Tidy.__wrap(ret);
    }
    /**
     * @param {number} parent_child_margin
     * @param {number} peer_margin
     * @returns {Tidy}
     */
    static with_layered_tidy(parent_child_margin, peer_margin) {
        const ret = wasm.tidy_with_layered_tidy(parent_child_margin, peer_margin);
        return Tidy.__wrap(ret);
    }
    /**
     * @param {WasmLayoutType} layout_type
     */
    change_layout(layout_type) {
        wasm.tidy_change_layout(this.__wbg_ptr, layout_type);
    }
    /**
     * @param {number} id
     */
    remove_node(id) {
        wasm.tidy_remove_node(this.__wbg_ptr, id);
    }
    /**
     * @returns {boolean}
     */
    is_empty() {
        const ret = wasm.tidy_is_empty(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {number} id
     * @param {number} width
     * @param {number} height
     * @param {number} parent_id
     */
    add_node(id, width, height, parent_id) {
        wasm.tidy_add_node(this.__wbg_ptr, id, width, height, parent_id);
    }
    /**
     * @param {Uint32Array} id
     * @param {Float64Array} width
     * @param {Float64Array} height
     * @param {Uint32Array} parent_id
     */
    data(id, width, height, parent_id) {
        const ptr0 = passArray32ToWasm0(id, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayF64ToWasm0(width, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArrayF64ToWasm0(height, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passArray32ToWasm0(parent_id, wasm.__wbindgen_malloc);
        const len3 = WASM_VECTOR_LEN;
        wasm.tidy_data(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
    }
    layout() {
        wasm.tidy_layout(this.__wbg_ptr);
    }
    /**
     * @param {Uint32Array} changed_ids
     */
    partial_layout(changed_ids) {
        const ptr0 = passArray32ToWasm0(changed_ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.tidy_partial_layout(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @returns {Float64Array}
     */
    get_pos() {
        const ret = wasm.tidy_get_pos(this.__wbg_ptr);
        var v1 = getArrayF64FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 8, 8);
        return v1;
    }
}
if (Symbol.dispose) Tidy.prototype[Symbol.dispose] = Tidy.prototype.free;

export function __wbg_buffer_b0511fd3a0f7d825(arg0) {
    const ret = arg0.buffer;
    return ret;
};

export function __wbg_call_7b07808271da073d() { return handleError(function (arg0, arg1) {
    const ret = arg0.call(arg1);
    return ret;
}, arguments) };

export function __wbg_crypto_3af587fe102cd5e0(arg0) {
    const ret = arg0.crypto;
    return ret;
};

export function __wbg_getRandomValues_dc8c0724059b50d5() { return handleError(function (arg0, arg1) {
    arg0.getRandomValues(arg1);
}, arguments) };

export function __wbg_globalThis_f95b2833d5f4cdb8() { return handleError(function () {
    const ret = globalThis.globalThis;
    return ret;
}, arguments) };

export function __wbg_global_8af85b9e930021de() { return handleError(function () {
    const ret = global.global;
    return ret;
}, arguments) };

export function __wbg_length_157c8bd57c7d16bf(arg0) {
    const ret = arg0.length;
    return ret;
};

export function __wbg_msCrypto_9cf2a2d7627b9321(arg0) {
    const ret = arg0.msCrypto;
    return ret;
};

export function __wbg_new_2113e2f7d64bfdb0(arg0) {
    const ret = new Uint8Array(arg0);
    return ret;
};

export function __wbg_newnoargs_64f19e6bf33dbf9c(arg0, arg1) {
    const ret = new Function(getStringFromWasm0(arg0, arg1));
    return ret;
};

export function __wbg_newwithlength_7c3d4eaaf370075c(arg0) {
    const ret = new Uint8Array(arg0 >>> 0);
    return ret;
};

export function __wbg_node_f6589410e2a90eef(arg0) {
    const ret = arg0.node;
    return ret;
};

export function __wbg_process_61c3a44060298372(arg0) {
    const ret = arg0.process;
    return ret;
};

export function __wbg_randomFillSync_5018017fb21d0285() { return handleError(function (arg0, arg1, arg2) {
    arg0.randomFillSync(getArrayU8FromWasm0(arg1, arg2));
}, arguments) };

export function __wbg_require_f7a1897a4e88366f() { return handleError(function (arg0, arg1, arg2) {
    const ret = arg0.require(getStringFromWasm0(arg1, arg2));
    return ret;
}, arguments) };

export function __wbg_self_59cc49f75c973fb6() { return handleError(function () {
    const ret = self.self;
    return ret;
}, arguments) };

export function __wbg_set_d46f77a7376b2305(arg0, arg1, arg2) {
    arg0.set(arg1, arg2 >>> 0);
};

export function __wbg_static_accessor_NODE_MODULE_06b864c18e8ae506() {
    const ret = module;
    return ret;
};

export function __wbg_subarray_b0627e03d3fe41dc(arg0, arg1, arg2) {
    const ret = arg0.subarray(arg1 >>> 0, arg2 >>> 0);
    return ret;
};

export function __wbg_versions_a4336e3a22b6d1c2(arg0) {
    const ret = arg0.versions;
    return ret;
};

export function __wbg_wbindgenisobject_307a53c6bd97fbf8(arg0) {
    const val = arg0;
    const ret = typeof(val) === 'object' && val !== null;
    return ret;
};

export function __wbg_wbindgenisstring_d4fa939789f003b0(arg0) {
    const ret = typeof(arg0) === 'string';
    return ret;
};

export function __wbg_wbindgenisundefined_c4b71d073b92f3c5(arg0) {
    const ret = arg0 === undefined;
    return ret;
};

export function __wbg_wbindgenmemory_d84da70f7c42d172() {
    const ret = wasm.memory;
    return ret;
};

export function __wbg_wbindgenthrow_451ec1a8469d7eb6(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
};

export function __wbg_window_f5a0f1c8f878e4c3() { return handleError(function () {
    const ret = window.window;
    return ret;
}, arguments) };

export function __wbindgen_init_externref_table() {
    const table = wasm.__wbindgen_export_2;
    const offset = table.grow(4);
    table.set(0, undefined);
    table.set(offset + 0, undefined);
    table.set(offset + 1, null);
    table.set(offset + 2, true);
    table.set(offset + 3, false);
    ;
};

