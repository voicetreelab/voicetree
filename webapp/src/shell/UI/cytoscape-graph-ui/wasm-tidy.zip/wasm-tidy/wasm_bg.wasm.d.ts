/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_tidy_free: (a: number, b: number) => void;
export const tidy_null_id: () => number;
export const tidy_with_basic_layout: (a: number, b: number) => number;
export const tidy_with_tidy_layout: (a: number, b: number) => number;
export const tidy_with_layered_tidy: (a: number, b: number) => number;
export const tidy_change_layout: (a: number, b: number) => void;
export const tidy_remove_node: (a: number, b: number) => void;
export const tidy_update_node_size: (a: number, b: number, c: number, d: number) => void;
export const tidy_set_parent: (a: number, b: number, c: number) => void;
export const tidy_is_empty: (a: number) => number;
export const tidy_add_node: (a: number, b: number, c: number, d: number, e: number) => void;
export const tidy_data: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => void;
export const tidy_layout: (a: number) => void;
export const tidy_partial_layout: (a: number, b: number, c: number) => void;
export const tidy_get_pos: (a: number) => [number, number];
export const start: () => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export_3: WebAssembly.Table;
export const __wbindgen_start: () => void;
